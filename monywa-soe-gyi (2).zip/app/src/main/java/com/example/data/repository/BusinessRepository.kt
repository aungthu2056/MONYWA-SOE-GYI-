package com.example.data.repository

import com.example.data.local.*
import com.example.domain.service.BackupDataContainer
import com.example.domain.service.BackupRestoreService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class BusinessRepository(private val database: AppDatabase) {

    val allShops: Flow<List<ShopEntity>> = database.shopDao().getAllShops()
    val allEmployees: Flow<List<EmployeeEntity>> = database.employeeDao().getAllEmployees()
    val allDailyWorkers: Flow<List<DailyWorkerEntity>> = database.dailyWorkerDao().getAllDailyWorkers()
    val allWorkerTypes: Flow<List<DailyWorkerTypeEntity>> = database.dailyWorkerTypeDao().getAllWorkerTypes()
    val allSettings: Flow<List<AppSettingEntity>> = database.appSettingDao().getAllSettings()
    val allIncome: Flow<List<IncomeEntity>> = database.incomeDao().getAllIncome()
    val allExpenses: Flow<List<ExpenseEntity>> = database.expenseDao().getAllExpenses()

    fun getAttendanceForMonth(month: String): Flow<List<AttendanceEntity>> =
        database.attendanceDao().getAttendanceForMonth(month)

    fun getAttendanceForEmployeeMonth(employeeId: String, month: String): Flow<List<AttendanceEntity>> =
        database.attendanceDao().getAttendanceForEmployeeMonth(employeeId, month)

    fun getAdvancesForMonth(month: String): Flow<List<AdvanceEntity>> =
        database.advanceDao().getAdvancesForMonth(month)

    fun getAdvancesForEmployee(employeeId: String): Flow<List<AdvanceEntity>> =
        database.advanceDao().getAdvancesForEmployee(employeeId)

    fun getAdvancesForEmployeeMonth(employeeId: String, month: String): Flow<List<AdvanceEntity>> =
        database.advanceDao().getAdvancesForEmployeeMonth(employeeId, month)

    fun getPayrollsForMonth(month: String): Flow<List<PayrollEntity>> =
        database.payrollDao().getPayrollsForMonth(month)

    fun getPayrollsForEmployee(employeeId: String): Flow<List<PayrollEntity>> =
        database.payrollDao().getPayrollsForEmployee(employeeId)

    fun getDailyWorkerEntriesForMonth(month: String): Flow<List<DailyWorkerEntryEntity>> =
        database.dailyWorkerEntryDao().getEntriesForMonth(month)

    fun getDailyWorkerEntriesForWorker(workerId: String): Flow<List<DailyWorkerEntryEntity>> =
        database.dailyWorkerEntryDao().getEntriesForWorker(workerId)

    fun getDailyWorkerSettlementsForMonth(month: String): Flow<List<DailyWorkerSettlementEntity>> =
        database.dailyWorkerSettlementDao().getSettlementsForMonth(month)

    fun getIncomeForMonth(month: String): Flow<List<IncomeEntity>> =
        database.incomeDao().getIncomeForMonth(month)

    fun getExpensesForMonth(month: String): Flow<List<ExpenseEntity>> =
        database.expenseDao().getExpensesForMonth(month)

    // Employees
    suspend fun saveEmployee(employee: EmployeeEntity) = withContext(Dispatchers.IO) {
        database.employeeDao().insertEmployee(employee)
    }

    suspend fun resignEmployee(employeeId: String, leaveDate: String) = withContext(Dispatchers.IO) {
        val existing = database.employeeDao().getEmployeeByIdDirect(employeeId)
        if (existing != null) {
            val updated = existing.copy(
                active = false,
                leaveDate = leaveDate,
                updatedAt = System.currentTimeMillis()
            )
            database.employeeDao().updateEmployee(updated)
        }
    }

    suspend fun deleteEmployee(employee: EmployeeEntity) = withContext(Dispatchers.IO) {
        database.employeeDao().deleteEmployee(employee)
    }

    // Attendance (Upsert by employeeId and date)
    suspend fun recordAttendance(
        employeeId: String,
        date: String,
        status: String,
        reason: String
    ) = withContext(Dispatchers.IO) {
        val id = "${employeeId}_${date}"
        val record = AttendanceEntity(
            id = id,
            employeeId = employeeId,
            date = date,
            status = status,
            reason = reason,
            updatedAt = System.currentTimeMillis()
        )
        database.attendanceDao().insertAttendance(record)
    }

    // Advances
    suspend fun addAdvance(advance: AdvanceEntity) = withContext(Dispatchers.IO) {
        database.advanceDao().insertAdvance(advance)
    }

    suspend fun updateAdvance(advance: AdvanceEntity) = withContext(Dispatchers.IO) {
        database.advanceDao().updateAdvance(advance)
    }

    suspend fun deleteAdvance(advance: AdvanceEntity) = withContext(Dispatchers.IO) {
        database.advanceDao().deleteAdvance(advance)
    }

    // Payroll
    suspend fun savePayrollSnapshot(payroll: PayrollEntity) = withContext(Dispatchers.IO) {
        database.payrollDao().insertPayroll(payroll)
    }

    suspend fun updatePayrollStatus(payrollId: String, status: String, paidDate: String?) = withContext(Dispatchers.IO) {
        val existing = database.payrollDao().getPayrollById(payrollId)
        if (existing != null) {
            val updated = existing.copy(
                status = status,
                paidDate = paidDate ?: existing.paidDate,
                updatedAt = System.currentTimeMillis()
            )
            database.payrollDao().updatePayroll(updated)
        }
    }

    // Daily Worker
    suspend fun saveDailyWorker(worker: DailyWorkerEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerDao().insertDailyWorker(worker)
    }

    suspend fun deleteDailyWorker(worker: DailyWorkerEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerDao().deleteDailyWorker(worker)
    }

    suspend fun saveDailyWorkerType(type: DailyWorkerTypeEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerTypeDao().insertWorkerType(type)
    }

    suspend fun saveDailyWorkerEntry(entry: DailyWorkerEntryEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerEntryDao().insertEntry(entry)
    }

    suspend fun updateDailyWorkerEntry(entry: DailyWorkerEntryEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerEntryDao().updateEntry(entry)
    }

    suspend fun deleteDailyWorkerEntry(entry: DailyWorkerEntryEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerEntryDao().deleteEntry(entry)
    }

    suspend fun saveDailyWorkerSettlement(settlement: DailyWorkerSettlementEntity) = withContext(Dispatchers.IO) {
        database.dailyWorkerSettlementDao().insertSettlement(settlement)
    }

    // Income
    suspend fun saveIncome(income: IncomeEntity) = withContext(Dispatchers.IO) {
        database.incomeDao().insertIncome(income)
    }

    suspend fun deleteIncome(income: IncomeEntity) = withContext(Dispatchers.IO) {
        database.incomeDao().deleteIncome(income)
    }

    // Expense
    suspend fun saveExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        database.expenseDao().insertExpense(expense)
    }

    suspend fun deleteExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        database.expenseDao().deleteExpense(expense)
    }

    // Shop
    suspend fun saveShop(shop: ShopEntity) = withContext(Dispatchers.IO) {
        database.shopDao().insertShop(shop)
    }

    suspend fun deleteShop(shop: ShopEntity) = withContext(Dispatchers.IO) {
        database.shopDao().deleteShop(shop)
    }

    // Settings
    suspend fun setSetting(key: String, value: String) = withContext(Dispatchers.IO) {
        database.appSettingDao().setSetting(AppSettingEntity(key = key, value = value))
    }

    suspend fun getSettingValue(key: String, defaultValue: String): String = withContext(Dispatchers.IO) {
        database.appSettingDao().getSetting(key)?.value ?: defaultValue
    }

    // Full Backup Export
    suspend fun exportAllDataAsJson(): String = withContext(Dispatchers.IO) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val container = BackupDataContainer(
            exportDate = dateFormat.format(Date()),
            appVersion = "1.0",
            businessName = database.appSettingDao().getSetting("business_name")?.value ?: "MONYWA SOE GYI",
            shops = database.shopDao().getAllShopsList(),
            employees = database.employeeDao().getAllEmployeesList(),
            attendance = database.attendanceDao().getAllAttendanceList(),
            advances = database.advanceDao().getAllAdvancesList(),
            payroll = database.payrollDao().getAllPayrollsList(),
            dailyWorkers = database.dailyWorkerDao().getAllDailyWorkersList(),
            dailyWorkerTypes = database.dailyWorkerTypeDao().getAllWorkerTypesList(),
            dailyWorkerEntries = database.dailyWorkerEntryDao().getAllEntriesList(),
            settlements = database.dailyWorkerSettlementDao().getAllSettlementsList(),
            income = database.incomeDao().getAllIncomeList(),
            expenses = database.expenseDao().getAllExpensesList(),
            settings = database.appSettingDao().getAllSettingsList()
        )
        BackupRestoreService.createBackupJson(container)
    }

    // Full Backup Restore / Safe Merge
    suspend fun restoreDataFromJson(jsonString: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val container = BackupRestoreService.parseBackupJson(jsonString)
            if (container.shops.isNotEmpty()) database.shopDao().insertShops(container.shops)
            if (container.employees.isNotEmpty()) database.employeeDao().insertEmployees(container.employees)
            if (container.attendance.isNotEmpty()) database.attendanceDao().insertAttendances(container.attendance)
            if (container.advances.isNotEmpty()) database.advanceDao().insertAdvances(container.advances)
            if (container.payroll.isNotEmpty()) database.payrollDao().insertPayrolls(container.payroll)
            if (container.dailyWorkers.isNotEmpty()) database.dailyWorkerDao().insertDailyWorkers(container.dailyWorkers)
            if (container.dailyWorkerTypes.isNotEmpty()) database.dailyWorkerTypeDao().insertWorkerTypes(container.dailyWorkerTypes)
            if (container.dailyWorkerEntries.isNotEmpty()) database.dailyWorkerEntryDao().insertEntries(container.dailyWorkerEntries)
            if (container.settlements.isNotEmpty()) database.dailyWorkerSettlementDao().insertSettlements(container.settlements)
            if (container.income.isNotEmpty()) database.incomeDao().insertIncomes(container.income)
            if (container.expenses.isNotEmpty()) database.expenseDao().insertExpenses(container.expenses)
            if (container.settings.isNotEmpty()) database.appSettingDao().setSettings(container.settings)

            val totalCount = container.employees.size + container.income.size + container.expenses.size +
                    container.payroll.size + container.dailyWorkerEntries.size
            Result.success(totalCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
