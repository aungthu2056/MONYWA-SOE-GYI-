package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        ShopEntity::class,
        EmployeeEntity::class,
        AttendanceEntity::class,
        AdvanceEntity::class,
        PayrollEntity::class,
        DailyWorkerEntity::class,
        DailyWorkerTypeEntity::class,
        DailyWorkerEntryEntity::class,
        DailyWorkerSettlementEntity::class,
        IncomeEntity::class,
        ExpenseEntity::class,
        AppSettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun shopDao(): ShopDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun advanceDao(): AdvanceDao
    abstract fun payrollDao(): PayrollDao
    abstract fun dailyWorkerDao(): DailyWorkerDao
    abstract fun dailyWorkerTypeDao(): DailyWorkerTypeDao
    abstract fun dailyWorkerEntryDao(): DailyWorkerEntryDao
    abstract fun dailyWorkerSettlementDao(): DailyWorkerSettlementDao
    abstract fun incomeDao(): IncomeDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun appSettingDao(): AppSettingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "monywa_soe_gyi_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(database: AppDatabase) {
            // Initial Shops
            val shop1 = ShopEntity(id = "shop_1", name = "ဆိုင်(၁)", active = true)
            val shop2 = ShopEntity(id = "shop_2", name = "ဆိုင်(၂)", active = true)
            database.shopDao().insertShops(listOf(shop1, shop2))

            // Initial Worker Types
            val workerType1 = DailyWorkerTypeEntity(
                id = "type_1",
                name = "ကွမ်းသီးစိတ်",
                unit = "ပိသာ",
                defaultRate = 10000.0
            )
            database.dailyWorkerTypeDao().insertWorkerType(workerType1)

            // Initial Employees (Legacy & existing business data)
            val employees = listOf(
                EmployeeEntity(
                    id = "emp_1",
                    business = "ကွမ်းယာဆိုင်ဝန်ထမ်းများ",
                    shop = "ဆိုင်(၁)",
                    name = "ကိုစိုး",
                    salary = 300000.0,
                    bonus = 50000.0,
                    employeeType = "monthly",
                    active = true
                ),
                EmployeeEntity(
                    id = "emp_2",
                    business = "ကွမ်းယာဆိုင်ဝန်ထမ်းများ",
                    shop = "ဆိုင်(၁)",
                    name = "မစိုး",
                    salary = 250000.0,
                    bonus = 0.0,
                    employeeType = "monthly",
                    active = true
                ),
                EmployeeEntity(
                    id = "emp_3",
                    business = "ကွမ်းယာဆိုင်ဝန်ထမ်းများ",
                    shop = "ဆိုင်(၁)",
                    name = "ကိုမျိုး",
                    salary = 300000.0,
                    bonus = 50000.0,
                    employeeType = "monthly",
                    active = true
                ),
                EmployeeEntity(
                    id = "emp_5",
                    business = "ကွမ်းယာဆိုင်ဝန်ထမ်းများ",
                    shop = "ဆိုင်(၁)",
                    name = "အောင်",
                    salary = 300000.0,
                    bonus = 30000.0,
                    employeeType = "monthly",
                    active = true
                ),
                EmployeeEntity(
                    id = "emp_6",
                    business = "ကွမ်းယာဆိုင်ဝန်ထမ်းများ",
                    shop = "ဆိုင်(၂)",
                    name = "မင်း",
                    salary = 280000.0,
                    bonus = 0.0,
                    employeeType = "monthly",
                    active = true
                )
            )
            database.employeeDao().insertEmployees(employees)

            // Initial Daily Worker
            val dailyWorker = DailyWorkerEntity(
                id = "worker_1",
                name = "တိုးတိုး",
                type = "ကွမ်းသီးစိတ်",
                active = true,
                notes = "ကွမ်းသီးစိတ် နေ့စား"
            )
            database.dailyWorkerDao().insertDailyWorker(dailyWorker)

            // Initial Settings
            val settings = listOf(
                AppSettingEntity(key = "business_name", value = "MONYWA SOE GYI"),
                AppSettingEntity(key = "attendance_penalty", value = "10000"),
                AppSettingEntity(key = "currency", value = "MMK"),
                AppSettingEntity(
                    key = "expense_categories",
                    value = "ကွမ်းယာဆိုင် (၁),ကွမ်းယာဆိုင် (၂),ဖိနပ်ဆိုင် (၁),ဖိနပ်ဆိုင် (၂),ကိုယ်ရေးကိုယ်တာ,အထွေထွေ"
                )
            )
            database.appSettingDao().setSettings(settings)
        }
    }
}
