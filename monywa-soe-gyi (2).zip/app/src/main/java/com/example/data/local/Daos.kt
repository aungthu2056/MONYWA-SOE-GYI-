package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopDao {
    @Query("SELECT * FROM shops ORDER BY name ASC")
    fun getAllShops(): Flow<List<ShopEntity>>

    @Query("SELECT * FROM shops WHERE active = 1 ORDER BY name ASC")
    fun getActiveShops(): Flow<List<ShopEntity>>

    @Query("SELECT * FROM shops")
    suspend fun getAllShopsList(): List<ShopEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShop(shop: ShopEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShops(shops: List<ShopEntity>)

    @Update
    suspend fun updateShop(shop: ShopEntity)

    @Delete
    suspend fun deleteShop(shop: ShopEntity)
}

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM employees ORDER BY name ASC")
    fun getAllEmployees(): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    fun getEmployeeById(id: String): Flow<EmployeeEntity?>

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun getEmployeeByIdDirect(id: String): EmployeeEntity?

    @Query("SELECT * FROM employees")
    suspend fun getAllEmployeesList(): List<EmployeeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: EmployeeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployees(employees: List<EmployeeEntity>)

    @Update
    suspend fun updateEmployee(employee: EmployeeEntity)

    @Delete
    suspend fun deleteEmployee(employee: EmployeeEntity)
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date LIKE :yearMonth || '%' ORDER BY date ASC")
    fun getAttendanceForEmployeeMonth(employeeId: String, yearMonth: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE date LIKE :yearMonth || '%' ORDER BY date ASC")
    fun getAttendanceForMonth(yearMonth: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND date = :date LIMIT 1")
    suspend fun getAttendanceByDate(employeeId: String, date: String): AttendanceEntity?

    @Query("SELECT * FROM attendance")
    suspend fun getAllAttendanceList(): List<AttendanceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: AttendanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendances(attendances: List<AttendanceEntity>)

    @Delete
    suspend fun deleteAttendance(attendance: AttendanceEntity)
}

@Dao
interface AdvanceDao {
    @Query("SELECT * FROM advances WHERE employeeId = :employeeId ORDER BY date DESC")
    fun getAdvancesForEmployee(employeeId: String): Flow<List<AdvanceEntity>>

    @Query("SELECT * FROM advances WHERE date LIKE :yearMonth || '%' ORDER BY date DESC")
    fun getAdvancesForMonth(yearMonth: String): Flow<List<AdvanceEntity>>

    @Query("SELECT * FROM advances WHERE employeeId = :employeeId AND date LIKE :yearMonth || '%' ORDER BY date DESC")
    fun getAdvancesForEmployeeMonth(employeeId: String, yearMonth: String): Flow<List<AdvanceEntity>>

    @Query("SELECT * FROM advances")
    suspend fun getAllAdvancesList(): List<AdvanceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdvance(advance: AdvanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdvances(advances: List<AdvanceEntity>)

    @Update
    suspend fun updateAdvance(advance: AdvanceEntity)

    @Delete
    suspend fun deleteAdvance(advance: AdvanceEntity)
}

@Dao
interface PayrollDao {
    @Query("SELECT * FROM payroll WHERE month = :month ORDER BY employeeName ASC")
    fun getPayrollsForMonth(month: String): Flow<List<PayrollEntity>>

    @Query("SELECT * FROM payroll WHERE employeeId = :employeeId ORDER BY month DESC")
    fun getPayrollsForEmployee(employeeId: String): Flow<List<PayrollEntity>>

    @Query("SELECT * FROM payroll WHERE id = :id LIMIT 1")
    suspend fun getPayrollById(id: String): PayrollEntity?

    @Query("SELECT * FROM payroll")
    suspend fun getAllPayrollsList(): List<PayrollEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayroll(payroll: PayrollEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayrolls(payrolls: List<PayrollEntity>)

    @Update
    suspend fun updatePayroll(payroll: PayrollEntity)

    @Delete
    suspend fun deletePayroll(payroll: PayrollEntity)
}

@Dao
interface DailyWorkerDao {
    @Query("SELECT * FROM daily_workers ORDER BY name ASC")
    fun getAllDailyWorkers(): Flow<List<DailyWorkerEntity>>

    @Query("SELECT * FROM daily_workers WHERE id = :id LIMIT 1")
    fun getDailyWorkerById(id: String): Flow<DailyWorkerEntity?>

    @Query("SELECT * FROM daily_workers")
    suspend fun getAllDailyWorkersList(): List<DailyWorkerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyWorker(worker: DailyWorkerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyWorkers(workers: List<DailyWorkerEntity>)

    @Update
    suspend fun updateDailyWorker(worker: DailyWorkerEntity)

    @Delete
    suspend fun deleteDailyWorker(worker: DailyWorkerEntity)
}

@Dao
interface DailyWorkerTypeDao {
    @Query("SELECT * FROM daily_worker_types ORDER BY name ASC")
    fun getAllWorkerTypes(): Flow<List<DailyWorkerTypeEntity>>

    @Query("SELECT * FROM daily_worker_types")
    suspend fun getAllWorkerTypesList(): List<DailyWorkerTypeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkerType(type: DailyWorkerTypeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkerTypes(types: List<DailyWorkerTypeEntity>)

    @Update
    suspend fun updateWorkerType(type: DailyWorkerTypeEntity)

    @Delete
    suspend fun deleteWorkerType(type: DailyWorkerTypeEntity)
}

@Dao
interface DailyWorkerEntryDao {
    @Query("SELECT * FROM daily_worker_entries WHERE date LIKE :yearMonth || '%' ORDER BY date DESC")
    fun getEntriesForMonth(yearMonth: String): Flow<List<DailyWorkerEntryEntity>>

    @Query("SELECT * FROM daily_worker_entries WHERE workerId = :workerId ORDER BY date DESC")
    fun getEntriesForWorker(workerId: String): Flow<List<DailyWorkerEntryEntity>>

    @Query("SELECT * FROM daily_worker_entries WHERE workerId = :workerId AND date LIKE :yearMonth || '%' ORDER BY date DESC")
    fun getEntriesForWorkerMonth(workerId: String, yearMonth: String): Flow<List<DailyWorkerEntryEntity>>

    @Query("SELECT * FROM daily_worker_entries")
    suspend fun getAllEntriesList(): List<DailyWorkerEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: DailyWorkerEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntries(entries: List<DailyWorkerEntryEntity>)

    @Update
    suspend fun updateEntry(entry: DailyWorkerEntryEntity)

    @Delete
    suspend fun deleteEntry(entry: DailyWorkerEntryEntity)
}

@Dao
interface DailyWorkerSettlementDao {
    @Query("SELECT * FROM daily_worker_settlements WHERE month = :month ORDER BY workerName ASC")
    fun getSettlementsForMonth(month: String): Flow<List<DailyWorkerSettlementEntity>>

    @Query("SELECT * FROM daily_worker_settlements WHERE workerId = :workerId ORDER BY month DESC")
    fun getSettlementsForWorker(workerId: String): Flow<List<DailyWorkerSettlementEntity>>

    @Query("SELECT * FROM daily_worker_settlements")
    suspend fun getAllSettlementsList(): List<DailyWorkerSettlementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlement(settlement: DailyWorkerSettlementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettlements(settlements: List<DailyWorkerSettlementEntity>)

    @Update
    suspend fun updateSettlement(settlement: DailyWorkerSettlementEntity)

    @Delete
    suspend fun deleteSettlement(settlement: DailyWorkerSettlementEntity)
}

@Dao
interface IncomeDao {
    @Query("SELECT * FROM income WHERE date LIKE :yearMonth || '%' ORDER BY date DESC")
    fun getIncomeForMonth(yearMonth: String): Flow<List<IncomeEntity>>

    @Query("SELECT * FROM income ORDER BY date DESC")
    fun getAllIncome(): Flow<List<IncomeEntity>>

    @Query("SELECT * FROM income")
    suspend fun getAllIncomeList(): List<IncomeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncome(income: IncomeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncomes(incomes: List<IncomeEntity>)

    @Update
    suspend fun updateIncome(income: IncomeEntity)

    @Delete
    suspend fun deleteIncome(income: IncomeEntity)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE date LIKE :yearMonth || '%' ORDER BY date DESC")
    fun getExpensesForMonth(yearMonth: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses")
    suspend fun getAllExpensesList(): List<ExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpenses(expenses: List<ExpenseEntity>)

    @Update
    suspend fun updateExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)
}

@Dao
interface AppSettingDao {
    @Query("SELECT * FROM app_settings")
    fun getAllSettings(): Flow<List<AppSettingEntity>>

    @Query("SELECT * FROM app_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): AppSettingEntity?

    @Query("SELECT * FROM app_settings")
    suspend fun getAllSettingsList(): List<AppSettingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: AppSettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSettings(settings: List<AppSettingEntity>)
}
