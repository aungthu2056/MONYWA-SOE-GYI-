package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shops")
data class ShopEntity(
    @PrimaryKey val id: String,
    val name: String,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "employees")
data class EmployeeEntity(
    @PrimaryKey val id: String,
    val business: String = "Monywa Soe Gyi",
    val shop: String,
    val name: String,
    val salary: Double = 0.0,
    val bonus: Double = 0.0,
    val joinDate: String? = null, // YYYY-MM-DD
    val leaveDate: String? = null, // YYYY-MM-DD
    val employeeType: String = "monthly", // monthly, daily
    val dayWorkerType: String? = null,
    val notes: String = "",
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey val id: String, // employeeId_date
    val employeeId: String,
    val date: String, // YYYY-MM-DD
    val status: String = "present", // present, absent, leave, holiday
    val reason: String = "", // နေမကောင်း, ကိုယ်ရေးကိစ္စ, etc.
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "advances")
data class AdvanceEntity(
    @PrimaryKey val id: String,
    val employeeId: String,
    val date: String, // YYYY-MM-DD
    val amount: Double = 0.0,
    val note: String = "",
    val payrollMonth: String? = null, // YYYY-MM
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "payroll")
data class PayrollEntity(
    @PrimaryKey val id: String, // employeeId_YYYY-MM
    val employeeId: String,
    val employeeName: String,
    val shop: String,
    val month: String, // YYYY-MM
    val baseSalary: Double = 0.0,
    val absentDays: Int = 0,
    val dailySalary: Double = 0.0,
    val absenceDeduction: Double = 0.0,
    val attendanceBonus: Double = 0.0,
    val attendancePenalty: Double = 0.0,
    val otherBonus: Double = 0.0,
    val advanceDeduction: Double = 0.0,
    val finalPay: Double = 0.0,
    val status: String = "draft", // draft, calculated, paid
    val paidDate: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_workers")
data class DailyWorkerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String = "ကွမ်းသီးစိတ်",
    val active: Boolean = true,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_worker_types")
data class DailyWorkerTypeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val unit: String = "ပိသာ",
    val defaultRate: Double = 10000.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_worker_entries")
data class DailyWorkerEntryEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val workerName: String,
    val date: String, // YYYY-MM-DD
    val workerType: String,
    val quantity: Double = 0.0,
    val unit: String = "ပိသာ",
    val pricePerUnit: Double = 0.0,
    val totalAmount: Double = 0.0, // quantity * pricePerUnit
    val advance: Double = 0.0,
    val notes: String = "",
    val settlementId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_worker_settlements")
data class DailyWorkerSettlementEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val workerName: String,
    val month: String, // YYYY-MM
    val totalQuantity: Double = 0.0,
    val totalEarned: Double = 0.0,
    val totalAdvance: Double = 0.0,
    val netPay: Double = 0.0,
    val settledDate: String = "",
    val status: String = "paid", // paid, pending
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "income")
data class IncomeEntity(
    @PrimaryKey val id: String,
    val date: String, // YYYY-MM-DD
    val shop: String,
    val amount: Double = 0.0,
    val description: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val date: String, // YYYY-MM-DD
    val category: String,
    val shop: String = "",
    val amount: Double = 0.0,
    val isPersonal: Boolean = false,
    val description: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)
