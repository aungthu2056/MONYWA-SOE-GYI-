package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AdvanceEntity
import com.example.data.local.AttendanceEntity
import com.example.data.local.EmployeeEntity
import com.example.domain.service.PayrollCalculationService
import com.example.ui.MainViewModel
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.MonthYearSelector
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

@Composable
fun EmployeeDetailScreen(
    employee: EmployeeEntity,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val currentMonthStr by viewModel.currentYearMonth.collectAsStateWithLifecycle()

    val allAttendance by viewModel.monthlyAttendance.collectAsStateWithLifecycle()
    val allAdvances by viewModel.monthlyAdvances.collectAsStateWithLifecycle()
    val allPayrolls by viewModel.monthlyPayrolls.collectAsStateWithLifecycle()

    val employeeAttendance = allAttendance.filter { it.employeeId == employee.id }
    val employeeAdvances = allAdvances.filter { it.employeeId == employee.id }
    val currentMonthPayroll = allPayrolls.find { it.employeeId == employee.id && it.month == currentMonthStr }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("အလုပ်တက်/ပျက်", "လစာ", "ကြိုတင်ငွေ", "မှတ်တမ်း")

    // Live calculation for preview
    val calculationResult = remember(employee, employeeAttendance, employeeAdvances, currentMonthStr) {
        PayrollCalculationService.calculateMonthlyPayroll(
            employee = employee,
            attendanceRecords = employeeAttendance,
            advances = employeeAdvances,
            yearMonth = currentMonthStr,
            penaltyRate = 10000.0,
            otherBonus = 0.0
        )
    }

    var showAdvanceDialog by remember { mutableStateOf(false) }
    var advanceToDelete by remember { mutableStateOf<AdvanceEntity?>(null) }
    var attendanceDateForReason by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Detail Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface,
            tonalElevation = 4.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = EmeraldPrimary
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = employee.name,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "${employee.shop} • ${if (employee.active) "လက်ရှိဝန်ထမ်း" else "အလုပ်ထွက်"}",
                            color = if (employee.active) EmeraldLight else AccentRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF005234))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = MainViewModel.formatCurrency(employee.salary),
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("ရက်မှန်ကြေး: ${MainViewModel.formatCurrency(employee.bonus)}", color = TextSecondary, fontSize = 12.sp)
                    Text("အလုပ်ဝင်: ${employee.joinDate ?: "-"}", color = TextMuted, fontSize = 12.sp)
                    if (!employee.active && employee.leaveDate != null) {
                        Text("ထွက်ရက်: ${employee.leaveDate}", color = AccentRed, fontSize = 12.sp)
                    }
                }
            }
        }

        // Month Selector
        MonthYearSelector(
            year = selectedYear,
            month = selectedMonth,
            onPrevMonth = { viewModel.prevMonth() },
            onNextMonth = { viewModel.nextMonth() },
            onSelectMonth = { y, m -> viewModel.setYearMonth(y, m) }
        )

        // Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = EmeraldPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = EmeraldPrimary
                )
            }
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) EmeraldPrimary else TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedTab) {
                0 -> AttendanceTab(
                    employee = employee,
                    year = selectedYear,
                    month = selectedMonth,
                    attendanceList = employeeAttendance,
                    onToggleAttendance = { date, currentStatus ->
                        val newStatus = if (currentStatus == "present") "absent" else "present"
                        if (newStatus == "absent") {
                            attendanceDateForReason = date
                        } else {
                            viewModel.recordAttendance(employee.id, date, "present", "")
                        }
                    }
                )
                1 -> PayrollTab(
                    employee = employee,
                    calculation = calculationResult,
                    currentMonthPayroll = currentMonthPayroll,
                    onSaveSnapshot = {
                        viewModel.calculateAndSavePayroll(employee, currentMonthStr, 0.0, "calculated")
                    },
                    onMarkPaid = {
                        if (currentMonthPayroll != null) {
                            viewModel.markPayrollPaid(currentMonthPayroll.id)
                        } else {
                            viewModel.calculateAndSavePayroll(employee, currentMonthStr, 0.0, "paid")
                        }
                    }
                )
                2 -> AdvancesTab(
                    advances = employeeAdvances,
                    onAddAdvanceClick = { showAdvanceDialog = true },
                    onDeleteAdvance = { advanceToDelete = it }
                )
                3 -> HistoryTab(
                    employeeId = employee.id,
                    viewModel = viewModel
                )
            }
        }
    }

    // Absence Reason Modal
    if (attendanceDateForReason != null) {
        val targetDate = attendanceDateForReason!!
        var selectedReason by remember { mutableStateOf("ကိုယ်ရေးကိစ္စ") }
        var customReason by remember { mutableStateOf("") }
        val reasonOptions = listOf("နေမကောင်း", "ကိုယ်ရေးကိစ္စ", "အရေးပေါ်ကိစ္စ", "အခြား")

        AlertDialog(
            onDismissRequest = { attendanceDateForReason = null },
            title = { Text("အလုပ်ပျက်ရတဲ့အကြောင်း", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ရက်စွဲ: $targetDate", color = EmeraldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    reasonOptions.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedReason == option) DarkSurfaceVariant else Color.Transparent)
                                .clickable { selectedReason = option }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedReason == option,
                                onClick = { selectedReason = option },
                                colors = RadioButtonDefaults.colors(selectedColor = EmeraldPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(option, color = TextPrimary, fontSize = 14.sp)
                        }
                    }
                    if (selectedReason == "အခြား") {
                        OutlinedTextField(
                            value = customReason,
                            onValueChange = { customReason = it },
                            label = { Text("အကြောင်းအရာ ရေးပါ") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = BorderStroke
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reason = if (selectedReason == "အခြား") customReason.ifBlank { "အခြား" } else selectedReason
                        viewModel.recordAttendance(employee.id, targetDate, "absent", reason)
                        attendanceDateForReason = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRed)
                ) {
                    Text("ပျက်ကွက်အဖြစ် မှတ်မည်", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { attendanceDateForReason = null }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Add Advance Modal
    if (showAdvanceDialog) {
        var amountStr by remember { mutableStateOf("") }
        var dateStr by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
        }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAdvanceDialog = false },
            title = { Text("ကြိုတင်ငွေ ထည့်သွင်းရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("ကြိုတင်ငွေ ပမာဏ (MMK) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )

                    OutlinedTextField(
                        value = dateStr,
                        onValueChange = { dateStr = it },
                        label = { Text("ရက်စွဲ (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("မှတ်ချက် (ဥပမာ- ဆေးဖိုး)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = amountStr.toDoubleOrNull() ?: 0.0
                        if (amount > 0) {
                            viewModel.addAdvance(employee.id, dateStr, amount, note)
                            showAdvanceDialog = false
                        } else {
                            viewModel.showMessage("ကြိုတင်ငွေ ပမာဏ မှန်ကန်စွာ ထည့်ပါ။")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("ထည့်မည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAdvanceDialog = false }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Delete Advance Confirmation
    if (advanceToDelete != null) {
        ConfirmationDialog(
            message = "ဒီကြိုတင်ငွေ (${MainViewModel.formatCurrency(advanceToDelete!!.amount)}) ကို ဖျက်မှာ သေချာပါသလား?",
            onConfirm = {
                advanceToDelete?.let { viewModel.deleteAdvance(it) }
                advanceToDelete = null
            },
            onDismiss = { advanceToDelete = null }
        )
    }
}

@Composable
private fun AttendanceTab(
    employee: EmployeeEntity,
    year: Int,
    month: Int,
    attendanceList: List<AttendanceEntity>,
    onToggleAttendance: (date: String, currentStatus: String) -> Unit
) {
    val cal = Calendar.getInstance()
    cal.set(Calendar.YEAR, year)
    cal.set(Calendar.MONTH, month - 1)
    val maxDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

    val absentCount = attendanceList.count { it.status == "absent" }
    val presentCount = attendanceList.count { it.status == "present" }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Attendance Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF064E3B)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("တက်ရောက်ရက်", color = EmeraldLight, fontSize = 12.sp)
                        Text("$presentCount ရက်", color = EmeraldPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF450A0A)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ပျက်ကွက်ရက်", color = Color(0xFFFCA5A5), fontSize = 12.sp)
                        Text("$absentCount ရက်", color = AccentRed, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        item {
            Text(
                text = "ရက်အလိုက် အလုပ်တက်/ပျက် (ထိပြီး အခြေအနေ ပြောင်းနိုင်သည်)",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // List of days
        items((1..maxDaysInMonth).toList()) { day ->
            val dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
            val record = attendanceList.find { it.date == dateStr }
            val status = record?.status ?: "present"
            val isAbsent = status == "absent"

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onToggleAttendance(dateStr, status) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isAbsent) Color(0xFF2C1515) else DarkSurface
                ),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isAbsent) AccentRed else BorderStroke)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(if (isAbsent) AccentRed.copy(alpha = 0.2f) else EmeraldPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$day",
                                color = if (isAbsent) AccentRed else EmeraldPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = dateStr,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            if (isAbsent && !record?.reason.isNullOrBlank()) {
                                Text(
                                    text = "အကြောင်း: ${record?.reason}",
                                    color = Color(0xFFFCA5A5),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Toggle status pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isAbsent) AccentRed else EmeraldPrimary)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isAbsent) "အလုပ်ပျက်" else "အလုပ်တက်",
                            color = if (isAbsent) Color.White else Color(0xFF003822),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PayrollTab(
    employee: EmployeeEntity,
    calculation: com.example.domain.service.PayrollCalculationResult,
    currentMonthPayroll: com.example.data.local.PayrollEntity?,
    onSaveSnapshot: () -> Unit,
    onMarkPaid: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Payroll Status Banner
        item {
            val isPaid = currentMonthPayroll?.status == "paid"
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isPaid) Color(0xFF064E3B) else DarkSurfaceElevated
                ),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isPaid) EmeraldPrimary else BorderStroke)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isPaid) "လစာ ရှင်းလင်းပြီး (Paid)" else "လစာ တွက်ချက်မှု (Calculated)",
                            color = if (isPaid) EmeraldLight else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isPaid) EmeraldPrimary else DarkSurfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isPaid) "ရှင်းပြီး" else "မရှင်းရသေး",
                                color = if (isPaid) Color(0xFF003822) else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = MainViewModel.formatCurrency(if (currentMonthPayroll != null) currentMonthPayroll.finalPay else calculation.finalPay),
                        color = EmeraldPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    if (isPaid && currentMonthPayroll?.paidDate != null) {
                        Text("ရှင်းလင်းသည့်ရက်: ${currentMonthPayroll.paidDate}", color = EmeraldLight, fontSize = 12.sp)
                    }
                }
            }
        }

        // Calculation Breakdown Table Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("လစာတွက်ချက်မှု အသေးစိတ် (Payroll Breakdown)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    PayrollRow("အခြေခံလစာ (Base Salary)", MainViewModel.formatCurrency(calculation.baseSalary), TextPrimary)
                    PayrollRow("တစ်ရက်လစာ (Daily = Salary / 30)", MainViewModel.formatCurrency(calculation.dailySalary), TextMuted)
                    PayrollRow("ပျက်ကွက်ရက် (${calculation.absentDays} ရက်)", "- ${MainViewModel.formatCurrency(calculation.absenceDeduction)}", AccentRed)

                    HorizontalDivider(color = BorderStroke, modifier = Modifier.padding(vertical = 8.dp))

                    PayrollRow("ရက်မှန်ကြေး အပြည့် (Full Bonus)", MainViewModel.formatCurrency(calculation.attendanceBonus), TextSecondary)
                    PayrollRow("ရက်မှန်ကြေး လျှော့ငွေ (Penalty)", "- ${MainViewModel.formatCurrency(calculation.attendancePenalty)}", AccentAmber)
                    PayrollRow("အမှန်ရ ရက်မှန်ကြေး (Effective Bonus)", "+ ${MainViewModel.formatCurrency(calculation.effectiveAttendanceBonus)}", EmeraldLight)

                    HorizontalDivider(color = BorderStroke, modifier = Modifier.padding(vertical = 8.dp))

                    PayrollRow("ကြိုတင်ငွေ နုတ်ပယ်မှု (Advances)", "- ${MainViewModel.formatCurrency(calculation.advanceDeduction)}", AccentAmber)

                    HorizontalDivider(color = EmeraldPrimary, thickness = 1.5.dp, modifier = Modifier.padding(vertical = 8.dp))

                    PayrollRow("အသားတင် ရရှိငွေ (Final Pay)", MainViewModel.formatCurrency(calculation.finalPay), EmeraldPrimary, isBold = true)
                }
            }
        }

        // Action Buttons
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSaveSnapshot,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldPrimary)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("တွက်ချက်သိမ်းဆည်း", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onMarkPaid,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF003822), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("လစာရှင်းပြီး", color = Color(0xFF003822), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PayrollRow(label: String, value: String, color: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isBold) TextPrimary else TextSecondary,
            fontSize = if (isBold) 14.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            color = color,
            fontSize = if (isBold) 16.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold
        )
    }
}

@Composable
private fun AdvancesTab(
    advances: List<AdvanceEntity>,
    onAddAdvanceClick: () -> Unit,
    onDeleteAdvance: (AdvanceEntity) -> Unit
) {
    val totalAdvances = advances.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ယခုလ ကြိုတင်ငွေ စုစုပေါင်း", color = TextSecondary, fontSize = 12.sp)
                        Text(
                            MainViewModel.formatCurrency(totalAdvances),
                            color = AccentAmber,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onAddAdvanceClick,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF003822), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ကြိုတင်ငွေထည့်", color = Color(0xFF003822), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (advances.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ကြိုတင်ငွေ မှတ်တမ်း မရှိပါ", color = TextMuted, fontSize = 14.sp)
                }
            }
        } else {
            items(advances) { advance ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = MainViewModel.formatCurrency(advance.amount),
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "ရက်စွဲ: ${advance.date} ${if (advance.note.isNotBlank()) "• ${advance.note}" else ""}",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        IconButton(onClick = { onDeleteAdvance(advance) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryTab(
    employeeId: String,
    viewModel: MainViewModel
) {
    val allPayrolls by viewModel.monthlyPayrolls.collectAsStateWithLifecycle()
    val employeePayrolls = allPayrolls.filter { it.employeeId == employeeId }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("လစာရှင်းတမ်း သမိုင်းမှတ်တမ်း (Payroll History Snapshots)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }

        if (employeePayrolls.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("လစာမှတ်တမ်း မရှိသေးပါ", color = TextMuted, fontSize = 14.sp)
                }
            }
        } else {
            items(employeePayrolls) { payroll ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(payroll.month, color = EmeraldPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                if (payroll.status == "paid") "ရှင်းပြီး (${payroll.paidDate ?: ""})" else "မရှင်းရသေး",
                                color = if (payroll.status == "paid") EmeraldLight else AccentAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("အခြေခံ: ${MainViewModel.formatCurrency(payroll.baseSalary)}", color = TextSecondary, fontSize = 12.sp)
                            Text("ပျက်ရက်: ${payroll.absentDays} ရက်", color = AccentRed, fontSize = 12.sp)
                            Text("ရက်မှန်ကြေး: ${MainViewModel.formatCurrency(payroll.attendanceBonus)}", color = EmeraldLight, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ကြိုတင်ငွေ: -${MainViewModel.formatCurrency(payroll.advanceDeduction)}", color = AccentAmber, fontSize = 12.sp)
                            Text("အသားတင်: ${MainViewModel.formatCurrency(payroll.finalPay)}", color = EmeraldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}
