package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ExpenseEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.MonthYearSelector
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ExpensesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val expenses by viewModel.allExpenses.collectAsStateWithLifecycle()
    val shops by viewModel.allShops.collectAsStateWithLifecycle()

    val searchQuery by viewModel.expenseSearchQuery.collectAsStateWithLifecycle()
    val shopFilter by viewModel.expenseShopFilter.collectAsStateWithLifecycle()
    val categoryFilter by viewModel.expenseCategoryFilter.collectAsStateWithLifecycle()

    val currentMonthStr = String.format(Locale.US, "%04d-%02d", selectedYear, selectedMonth)
    val monthlyExpenses = expenses.filter { it.date.startsWith(currentMonthStr) }

    // Categories available
    val defaultCategories = listOf(
        "ကွမ်းယာဆိုင် (၁)", "ကွမ်းယာဆိုင် (၂)", "ဖိနပ်ဆိုင် (၁)", "ဖိနပ်ဆိုင် (၂)", "ကိုယ်ရေးကိုယ်တာ", "အထွေထွေ"
    )

    // Filter
    val filteredExpenses = monthlyExpenses.filter { exp ->
        val matchesQuery = exp.description.contains(searchQuery, ignoreCase = true) || exp.notes.contains(searchQuery, ignoreCase = true)
        val matchesShop = shopFilter == "All" || exp.shop.equals(shopFilter, ignoreCase = true)
        val matchesCategory = categoryFilter == "All" || exp.category.equals(categoryFilter, ignoreCase = true)
        matchesQuery && matchesShop && matchesCategory
    }

    val totalAmount = filteredExpenses.sumOf { it.amount }
    val personalAmount = filteredExpenses.filter { it.isPersonal || it.category.contains("ကိုယ်ရေးကိုယ်တာ") }.sumOf { it.amount }
    val businessAmount = totalAmount - personalAmount

    var showAddDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<ExpenseEntity?>(null) }
    var expenseToDelete by remember { mutableStateOf<ExpenseEntity?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            item {
                AppHeader(
                    title = "အသုံးစာရင်း (Expenses)",
                    subtitle = "ဆိုင်နှင့် ကိုယ်ရေးကိုယ်တာ အသုံးစရိတ်များ"
                )
            }

            item {
                MonthYearSelector(
                    year = selectedYear,
                    month = selectedMonth,
                    onPrevMonth = { viewModel.prevMonth() },
                    onNextMonth = { viewModel.nextMonth() },
                    onSelectMonth = { y, m -> viewModel.setYearMonth(y, m) }
                )
            }

            // Summary Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentRed))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ယခုလ အသုံးစရိတ် စုစုပေါင်း", color = TextSecondary, fontSize = 13.sp)
                            Text(
                                MainViewModel.formatCurrency(totalAmount),
                                color = AccentRed,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 22.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ဆိုင်လုပ်ငန်းအသုံး: ${MainViewModel.formatCurrency(businessAmount)}", color = TextPrimary, fontSize = 12.sp)
                            Text("ကိုယ်ရေးကိုယ်တာ: ${MainViewModel.formatCurrency(personalAmount)}", color = AccentAmber, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.expenseSearchQuery.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    placeholder = { Text("အသုံးစရိတ် အကြောင်းအရာ ရှာရန်...", color = TextMuted) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderStroke,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
            }

            // Filters
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val catList = listOf("All") + defaultCategories
                    items(catList) { cat ->
                        val isSelected = categoryFilter == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.expenseCategoryFilter.value = cat },
                            label = { Text(if (cat == "All") "အမျိုးအစားအားလုံး" else cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentRed.copy(alpha = 0.8f),
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "အသုံးစရိတ် မှတ်တမ်းများ",
                    badgeText = "${filteredExpenses.size} ခု"
                )
            }

            if (filteredExpenses.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("အသုံးစရိတ် မှတ်တမ်း မရှိပါ", color = TextMuted)
                    }
                }
            } else {
                items(filteredExpenses) { expense ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = expense.description,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    if (expense.isPersonal) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF78350F))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("ကိုယ်ရေး", color = AccentAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${expense.date} • ${expense.category} ${if (expense.shop.isNotBlank()) "• ${expense.shop}" else ""}",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                                if (expense.notes.isNotBlank()) {
                                    Text(
                                        text = "မှတ်ချက်: ${expense.notes}",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = MainViewModel.formatCurrency(expense.amount),
                                    color = AccentRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(onClick = { expenseToDelete = expense }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 90.dp, end = 20.dp),
            containerColor = AccentRed,
            contentColor = Color.White
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Expense")
        }
    }

    // Add Expense Dialog
    if (showAddDialog) {
        ExpenseFormDialog(
            shops = shops.map { it.name },
            categories = defaultCategories,
            onDismiss = { showAddDialog = false },
            onSave = { date, category, shop, amount, isPersonal, description, notes ->
                viewModel.saveExpense(null, date, category, shop, amount, isPersonal, description, notes)
                showAddDialog = false
            }
        )
    }

    // Delete Confirmation
    if (expenseToDelete != null) {
        ConfirmationDialog(
            message = "ဒီအသုံးစရိတ် (${expenseToDelete!!.description} - ${MainViewModel.formatCurrency(expenseToDelete!!.amount)}) ကို ဖျက်မှာ သေချာပါသလား?",
            onConfirm = {
                expenseToDelete?.let { viewModel.deleteExpense(it) }
                expenseToDelete = null
            },
            onDismiss = { expenseToDelete = null }
        )
    }
}

@Composable
fun ExpenseFormDialog(
    shops: List<String>,
    categories: List<String>,
    onDismiss: () -> Unit,
    onSave: (date: String, category: String, shop: String, amount: Double, isPersonal: Boolean, description: String, notes: String) -> Unit
) {
    var date by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var selectedCategory by remember { mutableStateOf(categories.firstOrNull() ?: "ကွမ်းယာဆိုင် (၁)") }
    var selectedShop by remember { mutableStateOf(shops.firstOrNull() ?: "ဆိုင်(၁)") }
    var amountStr by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var isPersonal by remember { mutableStateOf(selectedCategory.contains("ကိုယ်ရေးကိုယ်တာ")) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("အသုံးစရိတ် အသစ်ထည့်ရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("ရက်စွဲ (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    Text("အသုံးစရိတ် အမျိုးအစား *", color = TextSecondary, fontSize = 12.sp)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(categories) { cat ->
                            val isSelected = selectedCategory == cat
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) AccentRed else DarkSurfaceVariant)
                                    .clickable {
                                        selectedCategory = cat
                                        if (cat.contains("ကိုယ်ရေးကိုယ်တာ")) isPersonal = true
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                color = Color.Transparent
                            ) {
                                Text(
                                    cat,
                                    color = if (isSelected) Color.White else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                item {
                    Text("ဆိုင် (ရွေးချယ်ရန်)", color = TextSecondary, fontSize = 12.sp)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(if (shops.isEmpty()) listOf("ဆိုင်(၁)", "ဆိုင်(၂)") else shops) { shop ->
                            val isSelected = selectedShop == shop
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) EmeraldPrimary else DarkSurfaceVariant)
                                    .clickable { selectedShop = shop }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                color = Color.Transparent
                            ) {
                                Text(
                                    shop,
                                    color = if (isSelected) Color(0xFF003822) else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("အကြောင်းအရာ * (ဥပမာ- ကွမ်းရွက်ဖိုး)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("ပမာဏ (MMK) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isPersonal = !isPersonal }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isPersonal,
                            onCheckedChange = { isPersonal = it },
                            colors = CheckboxDefaults.colors(checkedColor = AccentAmber)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ကိုယ်ရေးကိုယ်တာ အသုံးစရိတ် ဖြစ်သည်", color = TextPrimary, fontSize = 13.sp)
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("မှတ်ချက် (Notes)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    onSave(date, selectedCategory, selectedShop, amount, isPersonal, description, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentRed)
            ) {
                Text("ထည့်မည်", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("မလုပ်တော့ပါ", color = TextSecondary)
            }
        },
        containerColor = DarkSurface
    )
}
