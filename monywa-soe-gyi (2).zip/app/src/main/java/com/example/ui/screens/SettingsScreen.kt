package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val shops by viewModel.allShops.collectAsStateWithLifecycle()
    val employees by viewModel.allEmployees.collectAsStateWithLifecycle()
    val dailyWorkers by viewModel.allDailyWorkers.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showAddShopDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }

    var penaltyRateStr by remember { mutableStateOf("10000") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            AppHeader(
                title = "အပြင်အဆင် (Settings)",
                subtitle = "လုပ်ငန်း၊ ဆိုင်များနှင့် ဒေတာ အရန်သိမ်းဆည်းမှု"
            )
        }

        // Business Info Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("လုပ်ငန်း အချက်အလက်", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("လုပ်ငန်းအမည်: မုံရွာစိုးကြီး (MONYWA SOE GYI)", color = EmeraldLight, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("ငွေကြေး: မြန်မာကျပ်ငွေ (MMK)", color = TextSecondary, fontSize = 13.sp)
                }
            }
        }

        // Attendance Policy Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ရက်မှန်ကြေးနှင့် ပျက်ရက် စည်းမျဉ်း", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "• ပျက်ရက် ၁ ရက် သို့မဟုတ် ၂ ရက်: ရက်မှန်ကြေးမှ ၁၀,၀၀၀ ကျပ် ဖြတ်တောက်ပြီး ကျန်ငွေ ပေးချေသည်။\n• ပျက်ရက် ၃ ရက်နှင့် အထက်: ရက်မှန်ကြေး လုံးဝ မရရှိပါ။\n• နေ့စဉ်လစာ ဖြတ်တောက်မှု: (အခြေခံလစာ ÷ ၃၀) × ပျက်ကွက်ရက်။",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Manage Shops
        item {
            SectionHeader(
                title = "ဆိုင်များ စီမံခန့်ခွဲမှု (${shops.size} ဆိုင်)",
                actionText = "+ ဆိုင်အသစ်ထည့်",
                onActionClick = { showAddShopDialog = true }
            )
        }

        items(shops) { shop ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storefront, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(shop.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF005234))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Active", color = EmeraldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Backup & Restore Section
        item {
            Spacer(modifier = Modifier.height(10.dp))
            SectionHeader(title = "ဒေတာ အရန်သိမ်းဆည်းမှု (Backup & Restore)")

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Export Backup Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            coroutineScope.launch {
                                backupJsonText = viewModel.getBackupJson()
                                showBackupDialog = true
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("ဒေတာ အရန်သိမ်းဆည်းမည် (Export Backup)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("အချက်အလက် အားလုံးကို JSON ဖိုင်အဖြစ် သိမ်းဆည်းရန်", color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }

                // Import Restore Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showRestoreDialog = true },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("ဒေတာ ပြန်လည်ထည့်သွင်းမည် (Import Restore)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("ယခင် သိမ်းဆည်းထားသော ဒေတာ ပြန်သွင်းရန်", color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // App & System Info
        item {
            Spacer(modifier = Modifier.height(10.dp))
            SectionHeader(title = "စနစ် အခြေအနေ (System Info)")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("App Version: 1.0 (Production Mobile-First)", color = TextSecondary, fontSize = 13.sp)
                    Text("Database: Room Local Persistent DB + JSON Export", color = TextSecondary, fontSize = 13.sp)
                    Text("စုစုပေါင်း ဝန်ထမ်း: ${employees.size} ဦး", color = EmeraldLight, fontSize = 13.sp)
                    Text("စုစုပေါင်း နေ့စား: ${dailyWorkers.size} ဦး", color = AccentPurple, fontSize = 13.sp)
                }
            }
        }
    }

    // Add Shop Dialog
    if (showAddShopDialog) {
        var shopName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddShopDialog = false },
            title = { Text("ဆိုင်အသစ် ထည့်သွင်းရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("ဆိုင်အမည် (ဥပမာ- ဆိုင်(၃)) *") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderStroke
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveShop(shopName)
                        showAddShopDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("ထည့်မည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddShopDialog = false }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Export Backup Dialog
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("ဒေတာ အရန်သိမ်းဆည်းမှု (Backup JSON)", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("အောက်ပါ JSON ဒေတာကို ကူးယူပါ သို့မဟုတ် မျှဝေပါ:", color = TextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = backupJsonText.take(500) + if (backupJsonText.length > 500) "... (စုစုပေါင်း စာလုံးရေ: ${backupJsonText.length})" else "",
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("MonywaSoeGyiBackup", backupJsonText)
                            clipboard.setPrimaryClip(clip)
                            viewModel.showMessage("ဒေတာကို Clipboard သို့ ကူးယူပြီးပါပြီ။")
                            showBackupDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("Copy ကူးမည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Monywa Soe Gyi Backup")
                                putExtra(Intent.EXTRA_TEXT, backupJsonText)
                            }
                            context.startActivity(Intent.createChooser(intent, "Backup မျှဝေရန်"))
                            showBackupDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
                    ) {
                        Text("Share", color = Color.White)
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBackupDialog = false }) {
                    Text("ပိတ်မည်", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Import Restore Dialog
    if (showRestoreDialog) {
        var restoreText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("ဒေတာ ပြန်လည်ထည့်သွင်းရန် (Restore JSON)", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("အရန်သိမ်းဆည်းထားသော JSON စာသားကို Paste ချပါ:", color = TextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = restoreText,
                        onValueChange = { restoreText = it },
                        placeholder = { Text("ဒီနေရာတွင် JSON စာသား ထည့်ပါ...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreText.isNotBlank()) {
                            viewModel.restoreBackupJson(restoreText) { success ->
                                if (success) showRestoreDialog = false
                            }
                        } else {
                            viewModel.showMessage("JSON စာသား ထည့်သွင်းပါ။")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentAmber)
                ) {
                    Text("ပြန်လည်ထည့်သွင်းမည်", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRestoreDialog = false }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }
}
