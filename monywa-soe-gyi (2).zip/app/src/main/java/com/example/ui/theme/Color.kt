package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF00D084)
val EmeraldDark = Color(0xFF00A86B)
val EmeraldLight = Color(0xFF5CFFB8)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkSurfaceElevated = Color(0xFF253347)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentBlue = Color(0xFF38BDF8)
val AccentAmber = Color(0xFFFBBF24)
val AccentRed = Color(0xFFF87171)
val AccentPurple = Color(0xFFA855F7)

val BorderStroke = Color(0xFF334155)
val BorderHighlight = Color(0xFF00D084)

