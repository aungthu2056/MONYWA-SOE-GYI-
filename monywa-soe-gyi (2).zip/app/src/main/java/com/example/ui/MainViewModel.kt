package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.BusinessRepository
import com.example.domain.service.FinancialCalculationService
import com.example.domain.service.OverallFinancialReport
import com.example.domain.service.PayrollCalculationResult
import com.example.domain.service.PayrollCalculationService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

data class FinancialReportInput(
    val month: String,
    val shops: List<ShopEntity>,
    val incomes: List<IncomeEntity>,
    val expenses: List<ExpenseEntity>,
    val payrolls: List<PayrollEntity>
)

enum class AppScreen(val burmeseTitle: String) {
    DASHBOARD("ပင်မ"),
    EMPLOYEES("ဝန်ထမ်းများ"),
    DAILY_WORKERS("နေ့စား"),
    EXPENSES("အသုံးစာရင်း"),
    INCOME("ဝင်ငွေ"),
    PROFIT("အမြတ်"),
    SETTINGS("အပြင်အဆင်")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BusinessRepository

    init {
        val database = AppDatabase.getDatabase(application, viewModelScope)
        repository = BusinessRepository(database)
    }

    // Selected Date (Year & Month)
    private val calendar = Calendar.getInstance()
    private val _selectedYear = MutableStateFlow(calendar.get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonth = MutableStateFlow(calendar.get(Calendar.MONTH) + 1) // 1-indexed (1..12)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    val currentYearMonth: StateFlow<String> = combine(_selectedYear, _selectedMonth) { year, month ->
        String.format(Locale.US, "%04d-%02d", year, month)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, String.format(Locale.US, "%04d-%02d", calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1))

    // Navigation
    private val _currentScreen = MutableStateFlow(AppScreen.DASHBOARD)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedEmployee = MutableStateFlow<EmployeeEntity?>(null)
    val selectedEmployee: StateFlow<EmployeeEntity?> = _selectedEmployee.asStateFlow()

    private val _selectedDailyWorker = MutableStateFlow<DailyWorkerEntity?>(null)
    val selectedDailyWorker: StateFlow<DailyWorkerEntity?> = _selectedDailyWorker.asStateFlow()

    // Filters & Searches
    val employeeSearchQuery = MutableStateFlow("")
    val employeeShopFilter = MutableStateFlow("All") // All, ဆိုင်(၁), ဆိုင်(၂), etc.
    val employeeStatusFilter = MutableStateFlow("All") // All, Active, Resigned

    val incomeSearchQuery = MutableStateFlow("")
    val incomeShopFilter = MutableStateFlow("All")

    val expenseSearchQuery = MutableStateFlow("")
    val expenseShopFilter = MutableStateFlow("All")
    val expenseCategoryFilter = MutableStateFlow("All")

    // Database Flows
    val allShops = repository.allShops.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allEmployees = repository.allEmployees.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allDailyWorkers = repository.allDailyWorkers.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allWorkerTypes = repository.allWorkerTypes.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allSettings = repository.allSettings.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allIncome = repository.allIncome.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val allExpenses = repository.allExpenses.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val monthlyAttendance = currentYearMonth.flatMapLatest { month ->
        repository.getAttendanceForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val monthlyAdvances = currentYearMonth.flatMapLatest { month ->
        repository.getAdvancesForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val monthlyPayrolls = currentYearMonth.flatMapLatest { month ->
        repository.getPayrollsForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val monthlyDailyEntries = currentYearMonth.flatMapLatest { month ->
        repository.getDailyWorkerEntriesForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val monthlyDailySettlements = currentYearMonth.flatMapLatest { month ->
        repository.getDailyWorkerSettlementsForMonth(month)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Financial Report for current month
    val financialReport: StateFlow<OverallFinancialReport> = combine(
        currentYearMonth,
        allShops,
        allIncome,
        allExpenses,
        monthlyPayrolls
    ) { month, shops, incomes, expenses, payrolls ->
        FinancialReportInput(month, shops, incomes, expenses, payrolls)
    }.combine(monthlyDailyEntries) { input, dailyEntries ->
        val shopNames = input.shops.map { it.name }
        FinancialCalculationService.calculateFinancialReport(
            month = input.month,
            shops = shopNames,
            incomes = input.incomes,
            expenses = input.expenses,
            payrolls = input.payrolls,
            dailyWorkerEntries = dailyEntries
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.Lazily,
        OverallFinancialReport(
            month = "",
            totalIncome = 0.0,
            totalBusinessExpenses = 0.0,
            totalSalaries = 0.0,
            totalDailyWorkerCost = 0.0,
            businessProfit = 0.0,
            personalExpenses = 0.0,
            generalExpenses = 0.0,
            finalRemainingAmount = 0.0,
            shopSummaries = emptyList()
        )
    )

    // User Feedback (Snackbars / Toasts)
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun clearMessage() {
        _userMessage.value = null
    }

    fun setScreen(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectEmployee(employee: EmployeeEntity?) {
        _selectedEmployee.value = employee
    }

    fun selectDailyWorker(worker: DailyWorkerEntity?) {
        _selectedDailyWorker.value = worker
    }

    fun setYearMonth(year: Int, month: Int) {
        _selectedYear.value = year
        _selectedMonth.value = month
    }

    fun nextMonth() {
        if (_selectedMonth.value == 12) {
            _selectedYear.value += 1
            _selectedMonth.value = 1
        } else {
            _selectedMonth.value += 1
        }
    }

    fun prevMonth() {
        if (_selectedMonth.value == 1) {
            _selectedYear.value -= 1
            _selectedMonth.value = 12
        } else {
            _selectedMonth.value -= 1
        }
    }

    // --- Employee Operations ---
    fun saveEmployee(
        id: String?,
        name: String,
        shop: String,
        salary: Double,
        bonus: Double,
        joinDate: String?,
        leaveDate: String?,
        employeeType: String,
        notes: String
    ) {
        if (name.isBlank()) {
            showMessage("ဝန်ထမ်းအမည် ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val empId = id ?: "emp_${System.currentTimeMillis()}"
                val entity = EmployeeEntity(
                    id = empId,
                    name = name.trim(),
                    shop = shop.trim(),
                    salary = salary,
                    bonus = bonus,
                    joinDate = if (joinDate.isNullOrBlank()) null else joinDate.trim(),
                    leaveDate = if (leaveDate.isNullOrBlank()) null else leaveDate.trim(),
                    employeeType = employeeType,
                    notes = notes.trim(),
                    active = leaveDate.isNullOrBlank()
                )
                repository.saveEmployee(entity)
                if (_selectedEmployee.value?.id == empId) {
                    _selectedEmployee.value = entity
                }
                showMessage("ဝန်ထမ်းအချက်အလက် သိမ်းဆည်းပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("ဒေတာသိမ်းရာတွင် အမှားဖြစ်နေပါသည်: ${e.message}")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun resignEmployee(employeeId: String, leaveDate: String) {
        viewModelScope.launch {
            try {
                repository.resignEmployee(employeeId, leaveDate)
                showMessage("ဝန်ထမ်းအား အလုပ်ထွက်အဖြစ် သတ်မှတ်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun deleteEmployee(employee: EmployeeEntity) {
        viewModelScope.launch {
            try {
                repository.deleteEmployee(employee)
                if (_selectedEmployee.value?.id == employee.id) {
                    _selectedEmployee.value = null
                }
                showMessage("ဝန်ထမ်းမှတ်တမ်း ဖျက်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Attendance Operations ---
    fun recordAttendance(employeeId: String, date: String, status: String, reason: String) {
        viewModelScope.launch {
            try {
                repository.recordAttendance(employeeId, date, status, reason)
                showMessage("တက်ရောက်မှု မှတ်တမ်းတင်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Advance Operations ---
    fun addAdvance(employeeId: String, date: String, amount: Double, note: String) {
        if (amount <= 0) {
            showMessage("ကြိုတင်ငွေပမာဏ မှန်ကန်စွာ ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val advance = AdvanceEntity(
                    id = "adv_${System.currentTimeMillis()}",
                    employeeId = employeeId,
                    date = date,
                    amount = amount,
                    note = note.trim(),
                    payrollMonth = date.take(7)
                )
                repository.addAdvance(advance)
                showMessage("ကြိုတင်ငွေ မှတ်တမ်းတင်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun deleteAdvance(advance: AdvanceEntity) {
        viewModelScope.launch {
            try {
                repository.deleteAdvance(advance)
                showMessage("ကြိုတင်ငွေ မှတ်တမ်း ဖျက်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Payroll Operations ---
    fun calculateAndSavePayroll(
        employee: EmployeeEntity,
        yearMonth: String,
        otherBonus: Double = 0.0,
        status: String = "calculated"
    ) {
        viewModelScope.launch {
            try {
                val attendances = monthlyAttendance.value.filter { it.employeeId == employee.id }
                val advances = monthlyAdvances.value.filter { it.employeeId == employee.id }
                val penaltyStr = repository.getSettingValue("attendance_penalty", "10000")
                val penaltyRate = penaltyStr.toDoubleOrNull() ?: 10000.0

                val result = PayrollCalculationService.calculateMonthlyPayroll(
                    employee = employee,
                    attendanceRecords = attendances,
                    advances = advances,
                    yearMonth = yearMonth,
                    penaltyRate = penaltyRate,
                    otherBonus = otherBonus
                )

                val payrollSnapshot = PayrollEntity(
                    id = "${employee.id}_$yearMonth",
                    employeeId = employee.id,
                    employeeName = employee.name,
                    shop = employee.shop,
                    month = yearMonth,
                    baseSalary = result.baseSalary,
                    absentDays = result.absentDays,
                    dailySalary = result.dailySalary,
                    absenceDeduction = result.absenceDeduction,
                    attendanceBonus = result.attendanceBonus,
                    attendancePenalty = result.attendancePenalty,
                    otherBonus = result.otherBonus,
                    advanceDeduction = result.advanceDeduction,
                    finalPay = result.finalPay,
                    status = status,
                    paidDate = if (status == "paid") SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) else null
                )

                repository.savePayrollSnapshot(payrollSnapshot)
                showMessage("လစာစာရင်း သိမ်းဆည်းပြီးပါပြီ။ (အသားတင်: ${formatCurrency(result.finalPay)})")
            } catch (e: Exception) {
                showMessage("လစာတွက်ချက်ရာတွင် အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun markPayrollPaid(payrollId: String) {
        viewModelScope.launch {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            repository.updatePayrollStatus(payrollId, "paid", today)
            showMessage("လစာရှင်းပြီးအဖြစ် မှတ်တမ်းတင်ပြီးပါပြီ။")
        }
    }

    // --- Daily Worker Operations ---
    fun saveDailyWorker(id: String?, name: String, type: String, notes: String) {
        if (name.isBlank()) {
            showMessage("နေ့စား အမည် ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val workerId = id ?: "dw_${System.currentTimeMillis()}"
                val entity = DailyWorkerEntity(
                    id = workerId,
                    name = name.trim(),
                    type = type.trim(),
                    notes = notes.trim(),
                    active = true
                )
                repository.saveDailyWorker(entity)
                if (_selectedDailyWorker.value?.id == workerId) {
                    _selectedDailyWorker.value = entity
                }
                showMessage("နေ့စား အချက်အလက် သိမ်းဆည်းပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun saveDailyWorkerEntry(
        id: String?,
        worker: DailyWorkerEntity,
        date: String,
        workerType: String,
        quantity: Double,
        unit: String,
        pricePerUnit: Double,
        advance: Double,
        notes: String
    ) {
        if (quantity <= 0) {
            showMessage("ပမာဏ/အရေအတွက် မှန်ကန်စွာ ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val entryId = id ?: "dwe_${System.currentTimeMillis()}"
                val totalAmount = quantity * pricePerUnit
                val entry = DailyWorkerEntryEntity(
                    id = entryId,
                    workerId = worker.id,
                    workerName = worker.name,
                    date = date,
                    workerType = workerType,
                    quantity = quantity,
                    unit = unit,
                    pricePerUnit = pricePerUnit,
                    totalAmount = totalAmount,
                    advance = advance,
                    notes = notes.trim()
                )
                repository.saveDailyWorkerEntry(entry)
                showMessage("နေ့စားလုပ်ငန်း မှတ်တမ်းတင်ပြီးပါပြီ။ (စုစုပေါင်း: ${formatCurrency(totalAmount)})")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun deleteDailyWorkerEntry(entry: DailyWorkerEntryEntity) {
        viewModelScope.launch {
            try {
                repository.deleteDailyWorkerEntry(entry)
                showMessage("နေ့စားမှတ်တမ်း ဖျက်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun settleMonthDailyWorker(worker: DailyWorkerEntity, month: String) {
        viewModelScope.launch {
            try {
                val entries = monthlyDailyEntries.value.filter { it.workerId == worker.id }
                val totalQty = entries.sumOf { it.quantity }
                val totalEarned = entries.sumOf { it.totalAmount }
                val totalAdvance = entries.sumOf { it.advance }
                val netPay = totalEarned - totalAdvance

                val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                val settlement = DailyWorkerSettlementEntity(
                    id = "settle_${worker.id}_$month",
                    workerId = worker.id,
                    workerName = worker.name,
                    month = month,
                    totalQuantity = totalQty,
                    totalEarned = totalEarned,
                    totalAdvance = totalAdvance,
                    netPay = netPay,
                    settledDate = today,
                    status = "paid"
                )
                repository.saveDailyWorkerSettlement(settlement)
                showMessage("လကုန်ရှင်းလင်းပြီးပါပြီ။ (ကျန်ငွေပေးချေ: ${formatCurrency(netPay)})")
            } catch (e: Exception) {
                showMessage("လကုန်ရှင်းရာတွင် အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Income Operations ---
    fun saveIncome(id: String?, date: String, shop: String, amount: Double, description: String, notes: String) {
        if (amount <= 0) {
            showMessage("ဝင်ငွေပမာဏ မှန်ကန်စွာ ထည့်ပါ။")
            return
        }
        if (description.isBlank()) {
            showMessage("ဝင်ငွေအကြောင်းအရာ ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val income = IncomeEntity(
                    id = id ?: "inc_${System.currentTimeMillis()}",
                    date = date,
                    shop = shop.trim(),
                    amount = amount,
                    description = description.trim(),
                    notes = notes.trim()
                )
                repository.saveIncome(income)
                showMessage("ဝင်ငွေ မှတ်တမ်းတင်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun deleteIncome(income: IncomeEntity) {
        viewModelScope.launch {
            try {
                repository.deleteIncome(income)
                showMessage("ဝင်ငွေမှတ်တမ်း ဖျက်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Expense Operations ---
    fun saveExpense(
        id: String?,
        date: String,
        category: String,
        shop: String,
        amount: Double,
        isPersonal: Boolean,
        description: String,
        notes: String
    ) {
        if (amount <= 0) {
            showMessage("အသုံးစရိတ်ပမာဏ မှန်ကန်စွာ ထည့်ပါ။")
            return
        }
        if (description.isBlank()) {
            showMessage("အသုံးစရိတ်အကြောင်းအရာ ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val expense = ExpenseEntity(
                    id = id ?: "exp_${System.currentTimeMillis()}",
                    date = date,
                    category = category.trim(),
                    shop = shop.trim(),
                    amount = amount,
                    isPersonal = isPersonal || category.contains("ကိုယ်ရေးကိုယ်တာ"),
                    description = description.trim(),
                    notes = notes.trim()
                )
                repository.saveExpense(expense)
                showMessage("အသုံးစရိတ် မှတ်တမ်းတင်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            try {
                repository.deleteExpense(expense)
                showMessage("အသုံးစရိတ်မှတ်တမ်း ဖျက်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Settings & Shop Operations ---
    fun saveShop(name: String) {
        if (name.isBlank()) {
            showMessage("ဆိုင်အမည် ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val shop = ShopEntity(
                    id = "shop_${System.currentTimeMillis()}",
                    name = name.trim(),
                    active = true
                )
                repository.saveShop(shop)
                showMessage("ဆိုင်အသစ် ထည့်သွင်းပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun saveWorkerType(name: String, unit: String, rate: Double) {
        if (name.isBlank()) {
            showMessage("နေ့စားအမျိုးအစား ထည့်ပါ။")
            return
        }
        viewModelScope.launch {
            try {
                val type = DailyWorkerTypeEntity(
                    id = "type_${System.currentTimeMillis()}",
                    name = name.trim(),
                    unit = unit.trim().ifEmpty { "ပိသာ" },
                    defaultRate = rate
                )
                repository.saveDailyWorkerType(type)
                showMessage("နေ့စားအမျိုးအစား အသစ် ထည့်သွင်းပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    fun updateSetting(key: String, value: String) {
        viewModelScope.launch {
            try {
                repository.setSetting(key, value)
                showMessage("သတ်မှတ်ချက်များ ပြင်ဆင်ပြီးပါပြီ။")
            } catch (e: Exception) {
                showMessage("အမှားဖြစ်နေပါသည်: ${e.message}")
            }
        }
    }

    // --- Backup & Restore ---
    suspend fun getBackupJson(): String {
        return repository.exportAllDataAsJson()
    }

    fun restoreBackupJson(jsonString: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.restoreDataFromJson(jsonString)
            _isLoading.value = false
            if (result.isSuccess) {
                showMessage("ဒေတာ ${result.getOrNull()} ခု အောင်မြင်စွာ ပြန်လည်ထည့်သွင်းပြီးပါပြီ။")
                onComplete(true)
            } else {
                showMessage("ဒေတာပြန်ထည့်ရာတွင် အမှားဖြစ်နေပါသည်: ${result.exceptionOrNull()?.message}")
                onComplete(false)
            }
        }
    }

    companion object {
        private val numberFormat = DecimalFormat("#,###")

        fun formatCurrency(amount: Double): String {
            return "${numberFormat.format(amount.toLong())} MMK"
        }

        fun formatNumber(number: Double): String {
            return numberFormat.format(number)
        }
    }
}
