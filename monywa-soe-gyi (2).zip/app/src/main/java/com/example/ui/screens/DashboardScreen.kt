package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.MonthYearSelector
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatCard
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val report by viewModel.financialReport.collectAsStateWithLifecycle()
    val employees by viewModel.allEmployees.collectAsStateWithLifecycle()
    val dailyWorkers by viewModel.allDailyWorkers.collectAsStateWithLifecycle()
    val payrolls by viewModel.monthlyPayrolls.collectAsStateWithLifecycle()

    val activeEmployeesCount = employees.count { it.active }
    val resignedEmployeesCount = employees.count { !it.active }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            AppHeader(
                title = "မုံရွာစိုးကြီး",
                subtitle = "စီးပွားရေးနှင့် ဝန်ထမ်းစီမံခန့်ခွဲမှု"
            )
        }

        item {
            MonthYearSelector(
                year = selectedYear,
                month = selectedMonth,
                onPrevMonth = { viewModel.prevMonth() },
                onNextMonth = { viewModel.nextMonth() },
                onSelectMonth = { y, m -> viewModel.setYearMonth(y, m) }
            )
        }

        // Overall Final Profit Highlight Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(EmeraldPrimary))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "လက်ကျန် အသားတင် (Net Result)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF005234))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "အမြတ်",
                                color = EmeraldPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = MainViewModel.formatCurrency(report.finalRemainingAmount),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = if (report.finalRemainingAmount >= 0) EmeraldPrimary else AccentRed,
                            fontSize = 28.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = BorderStroke, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("လုပ်ငန်းအမြတ်", color = TextMuted, fontSize = 12.sp)
                            Text(
                                MainViewModel.formatCurrency(report.businessProfit),
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ကိုယ်ရေးကိုယ်တာ အသုံး", color = TextMuted, fontSize = 12.sp)
                            Text(
                                "- ${MainViewModel.formatCurrency(report.personalExpenses)}",
                                color = AccentAmber,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 4 Main Overall Metric Cards Grid
        item {
            SectionHeader(title = "ခြုံငုံသုံးသပ်ချက် (Overall Summary)")
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "စုစုပေါင်း ဝင်ငွေ",
                        value = MainViewModel.formatCurrency(report.totalIncome),
                        icon = Icons.Default.TrendingUp,
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setScreen(AppScreen.INCOME) }
                    )
                    StatCard(
                        title = "ဆိုင်အသုံးစရိတ်",
                        value = MainViewModel.formatCurrency(report.totalBusinessExpenses),
                        icon = Icons.Default.TrendingDown,
                        accentColor = AccentRed,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setScreen(AppScreen.EXPENSES) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatCard(
                        title = "ဝန်ထမ်းလစာများ",
                        value = MainViewModel.formatCurrency(report.totalSalaries),
                        icon = Icons.Default.People,
                        accentColor = AccentBlue,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setScreen(AppScreen.EMPLOYEES) }
                    )
                    StatCard(
                        title = "နေ့စားစရိတ်",
                        value = MainViewModel.formatCurrency(report.totalDailyWorkerCost),
                        icon = Icons.Default.WorkHistory,
                        accentColor = AccentPurple,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.setScreen(AppScreen.DAILY_WORKERS) }
                    )
                }
            }
        }

        // Shop Summaries (Shop 1 & Shop 2)
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(
                title = "ဆိုင်အလိုက် အမြတ်စာရင်း (Shop Summaries)",
                actionText = "အသေးစိတ်ကြည့်ရန်",
                onActionClick = { viewModel.setScreen(AppScreen.PROFIT) }
            )
        }

        items(report.shopSummaries) { shopSummary ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Storefront,
                                    contentDescription = null,
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = shopSummary.shopName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                        }

                        Text(
                            text = MainViewModel.formatCurrency(shopSummary.netProfit),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (shopSummary.netProfit >= 0) EmeraldPrimary else AccentRed
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ဝင်ငွေ", color = TextMuted, fontSize = 11.sp)
                            Text(
                                MainViewModel.formatCurrency(shopSummary.totalIncome),
                                color = EmeraldLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Column {
                            Text("အသုံးစရိတ်", color = TextMuted, fontSize = 11.sp)
                            Text(
                                MainViewModel.formatCurrency(shopSummary.totalExpenses),
                                color = AccentRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("လစာ", color = TextMuted, fontSize = 11.sp)
                            Text(
                                MainViewModel.formatCurrency(shopSummary.totalSalaries),
                                color = AccentBlue,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Quick Operational Status (Employees & Daily Workers)
        item {
            Spacer(modifier = Modifier.height(12.dp))
            SectionHeader(title = "ဝန်ထမ်းနှင့် လုပ်ငန်းအခြေအနေ (Operations)")

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setScreen(AppScreen.EMPLOYEES) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("လက်ရှိ ဝန်ထမ်း", color = TextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "$activeEmployeesCount ဦး",
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        if (resignedEmployeesCount > 0) {
                            Text(
                                "ထွက်ပြီး: $resignedEmployeesCount ဦး",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setScreen(AppScreen.DAILY_WORKERS) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("နေ့စား အလုပ်သမား", color = TextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "${dailyWorkers.size} ဦး",
                            color = AccentPurple,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            "စာရင်း: ${payrolls.count { it.status == "paid" }} ရှင်းပြီး",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
