package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.EmployeeEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EmployeesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val employees by viewModel.allEmployees.collectAsStateWithLifecycle()
    val shops by viewModel.allShops.collectAsStateWithLifecycle()
    val searchQuery by viewModel.employeeSearchQuery.collectAsStateWithLifecycle()
    val shopFilter by viewModel.employeeShopFilter.collectAsStateWithLifecycle()
    val statusFilter by viewModel.employeeStatusFilter.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var employeeToEdit by remember { mutableStateOf<EmployeeEntity?>(null) }
    var employeeToResign by remember { mutableStateOf<EmployeeEntity?>(null) }
    var employeeToDelete by remember { mutableStateOf<EmployeeEntity?>(null) }

    // Filter employees
    val filteredEmployees = employees.filter { emp ->
        val matchesQuery = emp.name.contains(searchQuery, ignoreCase = true)
        val matchesShop = shopFilter == "All" || emp.shop.equals(shopFilter, ignoreCase = true)
        val matchesStatus = when (statusFilter) {
            "Active" -> emp.active
            "Resigned" -> !emp.active
            else -> true
        }
        matchesQuery && matchesShop && matchesStatus
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            item {
                AppHeader(
                    title = "ဝန်ထမ်းများ",
                    subtitle = "စုစုပေါင်း: ${employees.size} ဦး (လက်ရှိ: ${employees.count { it.active }} ဦး)"
                )
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.employeeSearchQuery.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("ဝန်ထမ်းအမည် ရှာရန်...", color = TextMuted) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.employeeSearchQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = null, tint = TextMuted)
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderStroke,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
            }

            // Filter Chips (Shops & Status)
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Status filters
                    val statusOptions = listOf("All" to "အားလုံး", "Active" to "လက်ရှိ", "Resigned" to "အလုပ်ထွက်")
                    items(statusOptions) { (key, label) ->
                        val isSelected = statusFilter == key
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.employeeStatusFilter.value = key },
                            label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color(0xFF003822),
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) EmeraldPrimary else BorderStroke
                            )
                        )
                    }

                    // Shop filters
                    val shopList = listOf("All") + shops.map { it.name }
                    items(shopList) { shopName ->
                        val isSelected = shopFilter == shopName
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.employeeShopFilter.value = shopName },
                            label = { Text(if (shopName == "All") "ဆိုင်အားလုံး" else shopName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldDark,
                                selectedLabelColor = Color.White,
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "ဝန်ထမ်းစာရင်း",
                    badgeText = "${filteredEmployees.size} ဦး"
                )
            }

            if (filteredEmployees.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.PeopleOutline,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "ဝန်ထမ်းမှတ်တမ်း မရှိသေးပါ",
                                color = TextMuted,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else {
                items(filteredEmployees) { employee ->
                    EmployeeCard(
                        employee = employee,
                        onViewDetail = { viewModel.selectEmployee(employee) },
                        onEdit = { employeeToEdit = employee },
                        onResign = { employeeToResign = employee },
                        onDelete = { employeeToDelete = employee }
                    )
                }
            }
        }

        // Floating Action Button to Add Employee
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 90.dp, end = 20.dp),
            containerColor = EmeraldPrimary,
            contentColor = Color(0xFF003822)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Employee")
        }
    }

    // Add Employee Dialog
    if (showAddDialog) {
        EmployeeFormDialog(
            shops = shops.map { it.name },
            initialEmployee = null,
            onDismiss = { showAddDialog = false },
            onSave = { name, shop, salary, bonus, joinDate, leaveDate, type, notes ->
                viewModel.saveEmployee(null, name, shop, salary, bonus, joinDate, leaveDate, type, notes)
                showAddDialog = false
            }
        )
    }

    // Edit Employee Dialog
    if (employeeToEdit != null) {
        EmployeeFormDialog(
            shops = shops.map { it.name },
            initialEmployee = employeeToEdit,
            onDismiss = { employeeToEdit = null },
            onSave = { name, shop, salary, bonus, joinDate, leaveDate, type, notes ->
                viewModel.saveEmployee(employeeToEdit?.id, name, shop, salary, bonus, joinDate, leaveDate, type, notes)
                employeeToEdit = null
            }
        )
    }

    // Resign Dialog
    if (employeeToResign != null) {
        var leaveDateInput by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
        }
        AlertDialog(
            onDismissRequest = { employeeToResign = null },
            title = { Text("အလုပ်ထွက်အဖြစ် သတ်မှတ်ရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "${employeeToResign?.name} အား အလုပ်ထွက်အဖြစ် သတ်မှတ်မလား?\n(မှတ်တမ်းဟောင်းများနှင့် လစာမှတ်တမ်းများ ပျက်စီးမည်မဟုတ်ပါ)",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = leaveDateInput,
                        onValueChange = { leaveDateInput = it },
                        label = { Text("အလုပ်ထွက်ရက် (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        employeeToResign?.let { viewModel.resignEmployee(it.id, leaveDateInput) }
                        employeeToResign = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentAmber)
                ) {
                    Text("အလုပ်ထွက်မှတ်မည်", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { employeeToResign = null }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Delete Confirmation
    if (employeeToDelete != null) {
        ConfirmationDialog(
            title = "ဝန်ထမ်းမှတ်တမ်း ဖျက်ရန်",
            message = "${employeeToDelete?.name} ၏ အချက်အလက်ကို အပြီးတိုင် ဖျက်မှာ သေချာပါသလား?\n(အကြံပြုချက်: ဝန်ထမ်းထွက်သွားပါက 'အလုပ်ထွက်' အဖြစ်သာ သတ်မှတ်ပါ)",
            confirmText = "ဖျက်မည်",
            onConfirm = {
                employeeToDelete?.let { viewModel.deleteEmployee(it) }
                employeeToDelete = null
            },
            onDismiss = { employeeToDelete = null }
        )
    }
}

@Composable
fun EmployeeCard(
    employee: EmployeeEntity,
    onViewDetail: () -> Unit,
    onEdit: () -> Unit,
    onResign: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onViewDetail() },
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (employee.active) BorderStroke else AccentRed.copy(alpha = 0.5f))
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (employee.active) Color(0xFF005234) else DarkSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = employee.name.take(1),
                            color = if (employee.active) EmeraldPrimary else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = employee.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = employee.shop,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = EmeraldLight,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (employee.active) Color(0xFF005234) else Color(0xFF450A0A))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (employee.active) "လက်ရှိ" else "အလုပ်ထွက်",
                        color = if (employee.active) EmeraldPrimary else AccentRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = BorderStroke.copy(alpha = 0.5f), thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("အခြေခံလစာ", color = TextMuted, fontSize = 11.sp)
                    Text(
                        MainViewModel.formatCurrency(employee.salary),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Column {
                    Text("ရက်မှန်ကြေး", color = TextMuted, fontSize = 11.sp)
                    Text(
                        MainViewModel.formatCurrency(employee.bonus),
                        color = EmeraldPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("အလုပ်ဝင်ရက်", color = TextMuted, fontSize = 11.sp)
                    Text(
                        employee.joinDate ?: "-",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }

            if (!employee.active && employee.leaveDate != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ထွက်ရက်: ${employee.leaveDate}",
                    color = AccentRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onViewDetail,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("အသေးစိတ်", color = EmeraldPrimary, fontSize = 12.sp)
                }

                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }

                if (employee.active) {
                    IconButton(onClick = onResign, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.PersonOff, contentDescription = "Resign", tint = AccentAmber, modifier = Modifier.size(16.dp))
                    }
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun EmployeeFormDialog(
    shops: List<String>,
    initialEmployee: EmployeeEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, shop: String, salary: Double, bonus: Double, joinDate: String?, leaveDate: String?, type: String, notes: String) -> Unit
) {
    var name by remember { mutableStateOf(initialEmployee?.name ?: "") }
    var selectedShop by remember { mutableStateOf(initialEmployee?.shop ?: (shops.firstOrNull() ?: "ဆိုင်(၁)")) }
    var salaryStr by remember { mutableStateOf(initialEmployee?.salary?.toLong()?.toString() ?: "300000") }
    var bonusStr by remember { mutableStateOf(initialEmployee?.bonus?.toLong()?.toString() ?: "50000") }
    var joinDate by remember { mutableStateOf(initialEmployee?.joinDate ?: "") }
    var leaveDate by remember { mutableStateOf(initialEmployee?.leaveDate ?: "") }
    var notes by remember { mutableStateOf(initialEmployee?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (initialEmployee == null) "ဝန်ထမ်းအသစ်ထည့်ရန်" else "ဝန်ထမ်းအချက်အလက် ပြင်ဆင်ရန်",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("ဝန်ထမ်းအမည် *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                // Shop Dropdown / Chips
                item {
                    Text("တာဝန်ကျဆိုင် *", color = TextSecondary, fontSize = 12.sp)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(if (shops.isEmpty()) listOf("ဆိုင်(၁)", "ဆိုင်(၂)") else shops) { shop ->
                            val isSelected = selectedShop == shop
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) EmeraldPrimary else DarkSurfaceVariant)
                                    .clickable { selectedShop = shop }
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                color = Color.Transparent
                            ) {
                                Text(
                                    text = shop,
                                    color = if (isSelected) Color(0xFF003822) else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = salaryStr,
                        onValueChange = { salaryStr = it },
                        label = { Text("လစဉ် အခြေခံလစာ (MMK) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = bonusStr,
                        onValueChange = { bonusStr = it },
                        label = { Text("ရက်မှန်ကြေး / Bonus (MMK)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = joinDate,
                        onValueChange = { joinDate = it },
                        label = { Text("အလုပ်ဝင်ရက် (ဥပမာ- 2026-09-01)") },
                        placeholder = { Text("YYYY-MM-DD") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = leaveDate,
                        onValueChange = { leaveDate = it },
                        label = { Text("အလုပ်ထွက်ရက် (မရှိပါက အလွတ်ထားပါ)") },
                        placeholder = { Text("YYYY-MM-DD") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("မှတ်ချက် (Notes)") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val salary = salaryStr.toDoubleOrNull() ?: 0.0
                    val bonus = bonusStr.toDoubleOrNull() ?: 0.0
                    onSave(name, selectedShop, salary, bonus, joinDate.ifBlank { null }, leaveDate.ifBlank { null }, "monthly", notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("သိမ်းရန်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("မလုပ်တော့ပါ", color = TextSecondary)
            }
        },
        containerColor = DarkSurface
    )
}
