package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.MonthYearSelector
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*

@Composable
fun ProfitScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val report by viewModel.financialReport.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        item {
            AppHeader(
                title = "အမြတ်နှင့် အစီရင်ခံစာ (Profit & Reports)",
                subtitle = "ဆိုင်အလိုက် နှင့် လုပ်ငန်းတစ်ခုလုံး အမြတ်စာရင်း"
            )
        }

        item {
            MonthYearSelector(
                year = selectedYear,
                month = selectedMonth,
                onPrevMonth = { viewModel.prevMonth() },
                onNextMonth = { viewModel.nextMonth() },
                onSelectMonth = { y, m -> viewModel.setYearMonth(y, m) }
            )
        }

        // Final Remaining Net Result Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(EmeraldPrimary))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("လက်ကျန် အသားတင် (Final Remaining Result)", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        MainViewModel.formatCurrency(report.finalRemainingAmount),
                        color = if (report.finalRemainingAmount >= 0) EmeraldPrimary else AccentRed,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = BorderStroke, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("လုပ်ငန်းအမြတ်", color = TextMuted, fontSize = 12.sp)
                            Text(
                                MainViewModel.formatCurrency(report.businessProfit),
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ကိုယ်ရေးကိုယ်တာ အသုံး", color = TextMuted, fontSize = 12.sp)
                            Text(
                                "- ${MainViewModel.formatCurrency(report.personalExpenses)}",
                                color = AccentAmber,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Overall Breakdown Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("လုပ်ငန်းတစ်ခုလုံး အကျဉ်းချုပ် (Overall Business Statement)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    FinancialStatementRow("စုစုပေါင်း ဝင်ငွေ (Total Income)", MainViewModel.formatCurrency(report.totalIncome), EmeraldPrimary)
                    FinancialStatementRow("ဆိုင်အသုံးစရိတ် (Business Expenses)", "- ${MainViewModel.formatCurrency(report.totalBusinessExpenses)}", AccentRed)
                    FinancialStatementRow("ဝန်ထမ်းလစာများ (Employee Salaries)", "- ${MainViewModel.formatCurrency(report.totalSalaries)}", AccentBlue)
                    FinancialStatementRow("နေ့စားလုပ်ခများ (Daily Worker Cost)", "- ${MainViewModel.formatCurrency(report.totalDailyWorkerCost)}", AccentPurple)

                    HorizontalDivider(color = BorderStroke, modifier = Modifier.padding(vertical = 8.dp))

                    FinancialStatementRow("လုပ်ငန်းအမြတ် (Business Profit)", MainViewModel.formatCurrency(report.businessProfit), EmeraldLight, isBold = true)
                    FinancialStatementRow("ကိုယ်ရေးကိုယ်တာ အသုံး (Personal Expenses)", "- ${MainViewModel.formatCurrency(report.personalExpenses)}", AccentAmber)

                    HorizontalDivider(color = EmeraldPrimary, thickness = 1.5.dp, modifier = Modifier.padding(vertical = 8.dp))

                    FinancialStatementRow("လက်ကျန် အသားတင် (Final Net)", MainViewModel.formatCurrency(report.finalRemainingAmount), EmeraldPrimary, isBold = true)
                }
            }
        }

        // Shop-by-Shop Breakdown
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(title = "ဆိုင်အလိုက် အသေးစိတ် အမြတ်စာရင်း")
        }

        items(report.shopSummaries) { shop ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(shop.shopName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            MainViewModel.formatCurrency(shop.netProfit),
                            color = if (shop.netProfit >= 0) EmeraldPrimary else AccentRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    FinancialStatementRow("ဝင်ငွေ", MainViewModel.formatCurrency(shop.totalIncome), EmeraldLight)
                    FinancialStatementRow("အသုံးစရိတ်", "- ${MainViewModel.formatCurrency(shop.totalExpenses)}", AccentRed)
                    FinancialStatementRow("ဝန်ထမ်းလစာ", "- ${MainViewModel.formatCurrency(shop.totalSalaries)}", AccentBlue)

                    HorizontalDivider(color = BorderStroke, modifier = Modifier.padding(vertical = 6.dp))
                    FinancialStatementRow("ဆိုင်အမြတ် (Net Shop Profit)", MainViewModel.formatCurrency(shop.netProfit), EmeraldPrimary, isBold = true)
                }
            }
        }

        // Share / Export Report Button
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    shareReport(context, report, selectedYear, selectedMonth)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF003822), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("လချုပ် အစီရင်ခံစာ မျှဝေမည် (Share / Copy Report)", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun FinancialStatementRow(label: String, value: String, color: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = if (isBold) TextPrimary else TextSecondary,
            fontSize = if (isBold) 14.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = value,
            color = color,
            fontSize = if (isBold) 15.sp else 13.sp,
            fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold
        )
    }
}

private fun shareReport(context: Context, report: com.example.domain.service.OverallFinancialReport, year: Int, month: Int) {
    val text = buildString {
        appendLine("===============================")
        appendLine("မုံရွာစိုးကြီး - စီးပွားရေး လချုပ်ရှင်းတမ်း")
        appendLine("ကာလ: $year ခုနှစ်၊ $month လ (${report.month})")
        appendLine("===============================")
        appendLine("၁။ စုစုပေါင်း ဝင်ငွေ: ${MainViewModel.formatCurrency(report.totalIncome)}")
        appendLine("၂။ ဆိုင်အသုံးစရိတ် စုစုပေါင်း: ${MainViewModel.formatCurrency(report.totalBusinessExpenses)}")
        appendLine("၃။ ဝန်ထမ်းလစာ စုစုပေါင်း: ${MainViewModel.formatCurrency(report.totalSalaries)}")
        appendLine("၄။ နေ့စားလုပ်ခ စုစုပေါင်း: ${MainViewModel.formatCurrency(report.totalDailyWorkerCost)}")
        appendLine("-------------------------------")
        appendLine("လုပ်ငန်းအမြတ် (Business Profit): ${MainViewModel.formatCurrency(report.businessProfit)}")
        appendLine("ကိုယ်ရေးကိုယ်တာ အသုံး (Personal): -${MainViewModel.formatCurrency(report.personalExpenses)}")
        appendLine("-------------------------------")
        appendLine("လက်ကျန် အသားတင် (Final Net Cash): ${MainViewModel.formatCurrency(report.finalRemainingAmount)}")
        appendLine("===============================")
        appendLine("ဆိုင်အလိုက် အမြတ်စာရင်း:")
        report.shopSummaries.forEach { s ->
            appendLine("• ${s.shopName}: ဝင်ငွေ ${MainViewModel.formatCurrency(s.totalIncome)} - အသုံး ${MainViewModel.formatCurrency(s.totalExpenses)} - လစာ ${MainViewModel.formatCurrency(s.totalSalaries)} = အမြတ် ${MainViewModel.formatCurrency(s.netProfit)}")
        }
        appendLine("===============================")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "မုံရွာစိုးကြီး $year-$month လချုပ်စာရင်း")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "လချုပ်စာရင်း မျှဝေရန်"))
}
