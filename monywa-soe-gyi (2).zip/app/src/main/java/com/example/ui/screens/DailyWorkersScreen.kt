package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.DailyWorkerEntity
import com.example.data.local.DailyWorkerEntryEntity
import com.example.data.local.DailyWorkerTypeEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.MonthYearSelector
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DailyWorkersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val currentMonthStr by viewModel.currentYearMonth.collectAsStateWithLifecycle()

    val dailyWorkers by viewModel.allDailyWorkers.collectAsStateWithLifecycle()
    val workerTypes by viewModel.allWorkerTypes.collectAsStateWithLifecycle()
    val monthlyEntries by viewModel.monthlyDailyEntries.collectAsStateWithLifecycle()
    val monthlySettlements by viewModel.monthlyDailySettlements.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("နေ့စားစာရင်း", "စာရင်းချုပ် (Ledger)", "အမျိုးအစား/ဈေးနှုန်း")

    var showAddWorkerDialog by remember { mutableStateOf(false) }
    var workerForEntry by remember { mutableStateOf<DailyWorkerEntity?>(null) }
    var entryToDelete by remember { mutableStateOf<DailyWorkerEntryEntity?>(null) }
    var showAddTypeDialog by remember { mutableStateOf(false) }
    var selectedWorkerForLedger by remember { mutableStateOf<DailyWorkerEntity?>(null) }

    // Auto-select first worker if ledger selected
    LaunchedEffect(dailyWorkers) {
        if (selectedWorkerForLedger == null && dailyWorkers.isNotEmpty()) {
            selectedWorkerForLedger = dailyWorkers.first()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            AppHeader(
                title = "နေ့စားလုပ်ငန်း စီမံခန့်ခွဲမှု",
                subtitle = "ကွမ်းသီးစိတ် နှင့် နေ့စားလုပ်သားများ"
            )

            MonthYearSelector(
                year = selectedYear,
                month = selectedMonth,
                onPrevMonth = { viewModel.prevMonth() },
                onNextMonth = { viewModel.nextMonth() },
                onSelectMonth = { y, m -> viewModel.setYearMonth(y, m) }
            )

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = EmeraldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EmeraldPrimary
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) EmeraldPrimary else TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 80.dp)
            ) {
                when (selectedTab) {
                    0 -> DailyWorkersListTab(
                        workers = dailyWorkers,
                        entries = monthlyEntries,
                        onAddEntry = { workerForEntry = it },
                        onDeleteEntry = { entryToDelete = it },
                        onViewLedger = {
                            selectedWorkerForLedger = it
                            selectedTab = 1
                        }
                    )
                    1 -> DailyWorkerLedgerTab(
                        workers = dailyWorkers,
                        selectedWorker = selectedWorkerForLedger,
                        onSelectWorker = { selectedWorkerForLedger = it },
                        entries = monthlyEntries,
                        settlements = monthlySettlements,
                        month = currentMonthStr,
                        onSettleMonth = { worker ->
                            viewModel.settleMonthDailyWorker(worker, currentMonthStr)
                        },
                        onDeleteEntry = { entryToDelete = it }
                    )
                    2 -> DailyWorkerTypesTab(
                        types = workerTypes,
                        onAddTypeClick = { showAddTypeDialog = true }
                    )
                }
            }
        }

        // Floating Action Button
        if (selectedTab == 0) {
            FloatingActionButton(
                onClick = { showAddWorkerDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 90.dp, end = 20.dp),
                containerColor = EmeraldPrimary,
                contentColor = Color(0xFF003822)
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add Worker")
            }
        } else if (selectedTab == 2) {
            FloatingActionButton(
                onClick = { showAddTypeDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 90.dp, end = 20.dp),
                containerColor = EmeraldPrimary,
                contentColor = Color(0xFF003822)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Type")
            }
        }
    }

    // Add Daily Worker Dialog
    if (showAddWorkerDialog) {
        var name by remember { mutableStateOf("") }
        var type by remember { mutableStateOf(workerTypes.firstOrNull()?.name ?: "ကွမ်းသီးစိတ်") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddWorkerDialog = false },
            title = { Text("နေ့စားလုပ်သား အသစ်ထည့်ရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("လုပ်သားအမည် *") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                    OutlinedTextField(
                        value = type,
                        onValueChange = { type = it },
                        label = { Text("လုပ်ငန်းအမျိုးအစား (ဥပမာ- ကွမ်းသီးစိတ်)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("မှတ်ချက် (Notes)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveDailyWorker(null, name, type, notes)
                        showAddWorkerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("ထည့်မည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddWorkerDialog = false }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Add Entry Dialog for Worker
    if (workerForEntry != null) {
        val targetWorker = workerForEntry!!
        val defaultType = workerTypes.find { it.name == targetWorker.type } ?: workerTypes.firstOrNull()
        var dateStr by remember {
            mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
        }
        var workerType by remember { mutableStateOf(targetWorker.type) }
        var quantityStr by remember { mutableStateOf("1") }
        var unit by remember { mutableStateOf(defaultType?.unit ?: "ပိသာ") }
        var rateStr by remember { mutableStateOf(defaultType?.defaultRate?.toLong()?.toString() ?: "10000") }
        var advanceStr by remember { mutableStateOf("0") }
        var notes by remember { mutableStateOf("") }

        val currentQty = quantityStr.toDoubleOrNull() ?: 0.0
        val currentRate = rateStr.toDoubleOrNull() ?: 0.0
        val currentTotal = currentQty * currentRate

        AlertDialog(
            onDismissRequest = { workerForEntry = null },
            title = {
                Text(
                    "${targetWorker.name} ၏ နေ့စားလုပ်ငန်း မှတ်တမ်းတင်ရန်",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        OutlinedTextField(
                            value = dateStr,
                            onValueChange = { dateStr = it },
                            label = { Text("ရက်စွဲ (YYYY-MM-DD)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = BorderStroke
                            )
                        )
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = quantityStr,
                                onValueChange = { quantityStr = it },
                                label = { Text("အရေအတွက် *") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = BorderStroke
                                )
                            )
                            OutlinedTextField(
                                value = unit,
                                onValueChange = { unit = it },
                                label = { Text("ယူနစ် (ပိသာ/ခု)") },
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = BorderStroke
                                )
                            )
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = rateStr,
                            onValueChange = { rateStr = it },
                            label = { Text("၁ ယူနစ် ဈေးနှုန်း (MMK) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = BorderStroke
                            )
                        )
                    }

                    item {
                        // Total calculation preview
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF064E3B)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("စုစုပေါင်း ရငွေ:", color = EmeraldLight, fontSize = 13.sp)
                                Text(
                                    MainViewModel.formatCurrency(currentTotal),
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = advanceStr,
                            onValueChange = { advanceStr = it },
                            label = { Text("ကြိုထုတ်ငွေ / ကြိုတင်ငွေ (MMK)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = BorderStroke
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("မှတ်ချက် (Notes)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = EmeraldPrimary,
                                unfocusedBorderColor = BorderStroke
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = quantityStr.toDoubleOrNull() ?: 0.0
                        val rate = rateStr.toDoubleOrNull() ?: 0.0
                        val adv = advanceStr.toDoubleOrNull() ?: 0.0
                        viewModel.saveDailyWorkerEntry(
                            id = null,
                            worker = targetWorker,
                            date = dateStr,
                            workerType = workerType,
                            quantity = qty,
                            unit = unit,
                            pricePerUnit = rate,
                            advance = adv,
                            notes = notes
                        )
                        workerForEntry = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("သိမ်းဆည်းမည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { workerForEntry = null }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Add Worker Type Dialog
    if (showAddTypeDialog) {
        var typeName by remember { mutableStateOf("") }
        var typeUnit by remember { mutableStateOf("ပိသာ") }
        var rateStr by remember { mutableStateOf("10000") }

        AlertDialog(
            onDismissRequest = { showAddTypeDialog = false },
            title = { Text("နေ့စားအမျိုးအစား အသစ်ထည့်ရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = typeName,
                        onValueChange = { typeName = it },
                        label = { Text("အမျိုးအစား အမည် (ဥပမာ- ကွမ်းသီးစိတ်) *") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                    OutlinedTextField(
                        value = typeUnit,
                        onValueChange = { typeUnit = it },
                        label = { Text("ယူနစ် (ပိသာ/ခု/အိတ်)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it },
                        label = { Text("မူလ သတ်မှတ်နှုန်းထား (MMK)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val rate = rateStr.toDoubleOrNull() ?: 0.0
                        viewModel.saveWorkerType(typeName, typeUnit, rate)
                        showAddTypeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("ထည့်မည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddTypeDialog = false }) {
                    Text("မလုပ်တော့ပါ", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    // Delete Entry Confirmation
    if (entryToDelete != null) {
        ConfirmationDialog(
            message = "ဒီနေ့စားမှတ်တမ်း (${entryToDelete!!.workerName} - ${MainViewModel.formatCurrency(entryToDelete!!.totalAmount)}) ကို ဖျက်မှာ သေချာပါသလား?",
            onConfirm = {
                entryToDelete?.let { viewModel.deleteDailyWorkerEntry(it) }
                entryToDelete = null
            },
            onDismiss = { entryToDelete = null }
        )
    }
}

@Composable
private fun DailyWorkersListTab(
    workers: List<DailyWorkerEntity>,
    entries: List<DailyWorkerEntryEntity>,
    onAddEntry: (DailyWorkerEntity) -> Unit,
    onDeleteEntry: (DailyWorkerEntryEntity) -> Unit,
    onViewLedger: (DailyWorkerEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeader(title = "နေ့စားလုပ်သားများ (${workers.size} ဦး)")
        }

        if (workers.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("နေ့စားလုပ်သား မရှိသေးပါ", color = TextMuted)
                }
            }
        } else {
            items(workers) { worker ->
                val workerEntries = entries.filter { it.workerId == worker.id }
                val totalQty = workerEntries.sumOf { it.quantity }
                val totalEarned = workerEntries.sumOf { it.totalAmount }
                val totalAdvance = workerEntries.sumOf { it.advance }
                val net = totalEarned - totalAdvance

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(AccentPurple.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = worker.name.take(1),
                                        color = AccentPurple,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(worker.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(worker.type, color = TextSecondary, fontSize = 12.sp)
                                }
                            }

                            Button(
                                onClick = { onAddEntry(worker) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF003822), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("အလုပ်ထည့်", color = Color(0xFF003822), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = BorderStroke, thickness = 0.8.dp)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("စုစုပေါင်း အရေအတွက်", color = TextMuted, fontSize = 11.sp)
                                Text("$totalQty ပိသာ", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column {
                                Text("စုစုပေါင်း ရငွေ", color = TextMuted, fontSize = 11.sp)
                                Text(MainViewModel.formatCurrency(totalEarned), color = EmeraldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("ကျန်ငွေ", color = TextMuted, fontSize = 11.sp)
                                Text(MainViewModel.formatCurrency(net), color = EmeraldPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { onViewLedger(worker) }) {
                                Icon(Icons.Default.MenuBook, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("စာရင်းချုပ် / စာအုပ် ကြည့်ရန်", color = EmeraldPrimary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // Recent Entries this month
        item {
            Spacer(modifier = Modifier.height(12.dp))
            SectionHeader(title = "ယခုလ နေ့စားမှတ်တမ်းများ (${entries.size} ခု)")
        }

        if (entries.isEmpty()) {
            item {
                Text("ယခုလအတွက် နေ့စားမှတ်တမ်း မရှိသေးပါ", color = TextMuted, fontSize = 13.sp)
            }
        } else {
            items(entries) { entry ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${entry.workerName} • ${entry.workerType}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                "${entry.date} | ${entry.quantity} ${entry.unit} × ${MainViewModel.formatNumber(entry.pricePerUnit)} = ${MainViewModel.formatCurrency(entry.totalAmount)}",
                                color = EmeraldLight,
                                fontSize = 12.sp
                            )
                            if (entry.advance > 0) {
                                Text("ကြိုထုတ်: -${MainViewModel.formatCurrency(entry.advance)}", color = AccentAmber, fontSize = 11.sp)
                            }
                        }

                        IconButton(onClick = { onDeleteEntry(entry) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyWorkerLedgerTab(
    workers: List<DailyWorkerEntity>,
    selectedWorker: DailyWorkerEntity?,
    onSelectWorker: (DailyWorkerEntity) -> Unit,
    entries: List<DailyWorkerEntryEntity>,
    settlements: List<com.example.data.local.DailyWorkerSettlementEntity>,
    month: String,
    onSettleMonth: (DailyWorkerEntity) -> Unit,
    onDeleteEntry: (DailyWorkerEntryEntity) -> Unit
) {
    if (selectedWorker == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("နေ့စားလုပ်သား ရွေးချယ်ပါ", color = TextMuted)
        }
        return
    }

    val workerEntries = entries.filter { it.workerId == selectedWorker.id }
    val totalQty = workerEntries.sumOf { it.quantity }
    val totalEarned = workerEntries.sumOf { it.totalAmount }
    val totalAdvance = workerEntries.sumOf { it.advance }
    val netPay = totalEarned - totalAdvance
    val isSettled = settlements.any { it.workerId == selectedWorker.id && it.month == month }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Worker Selector Dropdown / Chips
        item {
            Text("လုပ်သား ရွေးချယ်ရန်:", color = TextSecondary, fontSize = 12.sp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                workers.forEach { worker ->
                    val isSelected = worker.id == selectedWorker.id
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) EmeraldPrimary else DarkSurfaceVariant)
                            .clickable { onSelectWorker(worker) }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.Transparent
                    ) {
                        Text(
                            worker.name,
                            color = if (isSelected) Color(0xFF003822) else TextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Ledger Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(EmeraldPrimary))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${selectedWorker.name} ($month စာရင်းချုပ်)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (isSettled) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF005234))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("လကုန်ရှင်းပြီး", color = EmeraldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("စုစုပေါင်း ပမာဏ", color = TextMuted, fontSize = 11.sp)
                            Text("$totalQty ပိသာ", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column {
                            Text("ရငွေ စုစုပေါင်း", color = TextMuted, fontSize = 11.sp)
                            Text(MainViewModel.formatCurrency(totalEarned), color = EmeraldLight, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ကြိုထုတ်ငွေ", color = TextMuted, fontSize = 11.sp)
                            Text("- ${MainViewModel.formatCurrency(totalAdvance)}", color = AccentAmber, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = BorderStroke, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ကျန်ငွေ ပေးချေရန် (Net Pay):", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text(MainViewModel.formatCurrency(netPay), color = EmeraldPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { onSettleMonth(selectedWorker) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF003822), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("လကုန်ရှင်းလင်းမည် (Settle Month)", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            SectionHeader(title = "နေ့စဉ် လုပ်ငန်းမှတ်တမ်းများ")
        }

        if (workerEntries.isEmpty()) {
            item {
                Text("ယခုလအတွက် လုပ်ငန်းမှတ်တမ်း မရှိပါ", color = TextMuted, fontSize = 13.sp)
            }
        } else {
            items(workerEntries) { entry ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(entry.date, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                "${entry.quantity} ${entry.unit} × ${MainViewModel.formatNumber(entry.pricePerUnit)} = ${MainViewModel.formatCurrency(entry.totalAmount)}",
                                color = EmeraldLight,
                                fontSize = 12.sp
                            )
                            if (entry.advance > 0) {
                                Text("ကြိုထုတ်: -${MainViewModel.formatCurrency(entry.advance)}", color = AccentAmber, fontSize = 11.sp)
                            }
                        }

                        IconButton(onClick = { onDeleteEntry(entry) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyWorkerTypesTab(
    types: List<DailyWorkerTypeEntity>,
    onAddTypeClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeader(
                title = "နေ့စားအမျိုးအစား & ဈေးနှုန်း သတ်မှတ်ချက်",
                actionText = "+ အသစ်ထည့်",
                onActionClick = onAddTypeClick
            )
        }

        items(types) { type ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(type.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("၁ ${type.unit} လျှင်", color = TextMuted, fontSize = 12.sp)
                    }

                    Text(
                        MainViewModel.formatCurrency(type.defaultRate),
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}
