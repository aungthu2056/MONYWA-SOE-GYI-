package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.IncomeEntity
import com.example.ui.MainViewModel
import com.example.ui.components.AppHeader
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.MonthYearSelector
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun IncomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val incomes by viewModel.allIncome.collectAsStateWithLifecycle()
    val shops by viewModel.allShops.collectAsStateWithLifecycle()

    val searchQuery by viewModel.incomeSearchQuery.collectAsStateWithLifecycle()
    val shopFilter by viewModel.incomeShopFilter.collectAsStateWithLifecycle()

    val currentMonthStr = String.format(Locale.US, "%04d-%02d", selectedYear, selectedMonth)
    val monthlyIncomes = incomes.filter { it.date.startsWith(currentMonthStr) }

    val filteredIncomes = monthlyIncomes.filter { inc ->
        val matchesQuery = inc.description.contains(searchQuery, ignoreCase = true) || inc.notes.contains(searchQuery, ignoreCase = true)
        val matchesShop = shopFilter == "All" || inc.shop.equals(shopFilter, ignoreCase = true)
        matchesQuery && matchesShop
    }

    val totalIncome = filteredIncomes.sumOf { it.amount }

    var showAddDialog by remember { mutableStateOf(false) }
    var incomeToDelete by remember { mutableStateOf<IncomeEntity?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            item {
                AppHeader(
                    title = "ဝင်ငွေစာရင်း (Income)",
                    subtitle = "ဆိုင်အလိုက် နေ့စဉ်နှင့် လစဉ် ဝင်ငွေများ"
                )
            }

            item {
                MonthYearSelector(
                    year = selectedYear,
                    month = selectedMonth,
                    onPrevMonth = { viewModel.prevMonth() },
                    onNextMonth = { viewModel.nextMonth() },
                    onSelectMonth = { y, m -> viewModel.setYearMonth(y, m) }
                )
            }

            // Total Income Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF064E3B)),
                    shape = RoundedCornerShape(16.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(EmeraldPrimary))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("ယခုလ ဝင်ငွေ စုစုပေါင်း", color = EmeraldLight, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            MainViewModel.formatCurrency(totalIncome),
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 24.sp
                        )
                    }
                }
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.incomeSearchQuery.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    placeholder = { Text("ဝင်ငွေ အကြောင်းအရာ ရှာရန်...", color = TextMuted) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderStroke,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
            }

            // Shop Filters
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val shopList = listOf("All") + shops.map { it.name }
                    items(shopList) { shopName ->
                        val isSelected = shopFilter == shopName
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.incomeShopFilter.value = shopName },
                            label = { Text(if (shopName == "All") "ဆိုင်အားလုံး" else shopName) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color(0xFF003822),
                                containerColor = DarkSurface,
                                labelColor = TextSecondary
                            )
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "ဝင်ငွေ မှတ်တမ်းများ",
                    badgeText = "${filteredIncomes.size} ခု"
                )
            }

            if (filteredIncomes.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ဝင်ငွေ မှတ်တမ်း မရှိပါ", color = TextMuted)
                    }
                }
            } else {
                items(filteredIncomes) { income ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderStroke))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(income.description, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("${income.date} • ${income.shop}", color = EmeraldLight, fontSize = 12.sp)
                                if (income.notes.isNotBlank()) {
                                    Text("မှတ်ချက်: ${income.notes}", color = TextMuted, fontSize = 11.sp)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    MainViewModel.formatCurrency(income.amount),
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(onClick = { incomeToDelete = income }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AccentRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 90.dp, end = 20.dp),
            containerColor = EmeraldPrimary,
            contentColor = Color(0xFF003822)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Income")
        }
    }

    // Add Income Dialog
    if (showAddDialog) {
        IncomeFormDialog(
            shops = shops.map { it.name },
            onDismiss = { showAddDialog = false },
            onSave = { date, shop, amount, description, notes ->
                viewModel.saveIncome(null, date, shop, amount, description, notes)
                showAddDialog = false
            }
        )
    }

    // Delete Confirmation
    if (incomeToDelete != null) {
        ConfirmationDialog(
            message = "ဒီဝင်ငွေ (${incomeToDelete!!.description} - ${MainViewModel.formatCurrency(incomeToDelete!!.amount)}) ကို ဖျက်မှာ သေချာပါသလား?",
            onConfirm = {
                incomeToDelete?.let { viewModel.deleteIncome(it) }
                incomeToDelete = null
            },
            onDismiss = { incomeToDelete = null }
        )
    }
}

@Composable
fun IncomeFormDialog(
    shops: List<String>,
    onDismiss: () -> Unit,
    onSave: (date: String, shop: String, amount: Double, description: String, notes: String) -> Unit
) {
    var date by remember {
        mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
    }
    var selectedShop by remember { mutableStateOf(shops.firstOrNull() ?: "ဆိုင်(၁)") }
    var amountStr by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ဝင်ငွေ အသစ်ထည့်ရန်", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("ရက်စွဲ (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    Text("ဆိုင် *", color = TextSecondary, fontSize = 12.sp)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(if (shops.isEmpty()) listOf("ဆိုင်(၁)", "ဆိုင်(၂)") else shops) { shop ->
                            val isSelected = selectedShop == shop
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) EmeraldPrimary else DarkSurfaceVariant)
                                    .clickable { selectedShop = shop }
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                color = Color.Transparent
                            ) {
                                Text(
                                    shop,
                                    color = if (isSelected) Color(0xFF003822) else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("အကြောင်းအရာ * (ဥပမာ- နေ့စဉ် အရောင်းရငွေ)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("ဝင်ငွေ ပမာဏ (MMK) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("မှတ်ချက် (Notes)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderStroke
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    onSave(date, selectedShop, amount, description, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("ထည့်မည်", color = Color(0xFF003822), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("မလုပ်တော့ပါ", color = TextSecondary)
            }
        },
        containerColor = DarkSurface
    )
}
