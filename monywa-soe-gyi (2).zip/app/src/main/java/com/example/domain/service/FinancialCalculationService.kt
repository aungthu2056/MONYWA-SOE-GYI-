package com.example.domain.service

import com.example.data.local.ExpenseEntity
import com.example.data.local.IncomeEntity
import com.example.data.local.PayrollEntity
import com.example.data.local.DailyWorkerEntryEntity

data class ShopFinancialSummary(
    val shopName: String,
    val totalIncome: Double,
    val totalExpenses: Double,
    val totalSalaries: Double,
    val totalDailyWorkerCost: Double,
    val netProfit: Double
)

data class OverallFinancialReport(
    val month: String,
    val totalIncome: Double,
    val totalBusinessExpenses: Double,
    val totalSalaries: Double,
    val totalDailyWorkerCost: Double,
    val businessProfit: Double,
    val personalExpenses: Double,
    val generalExpenses: Double,
    val finalRemainingAmount: Double,
    val shopSummaries: List<ShopFinancialSummary>
)

object FinancialCalculationService {

    fun calculateFinancialReport(
        month: String, // YYYY-MM
        shops: List<String>,
        incomes: List<IncomeEntity>,
        expenses: List<ExpenseEntity>,
        payrolls: List<PayrollEntity>,
        dailyWorkerEntries: List<DailyWorkerEntryEntity>
    ): OverallFinancialReport {
        // Filter by month
        val monthIncomes = incomes.filter { it.date.startsWith(month) }
        val monthExpenses = expenses.filter { it.date.startsWith(month) }
        val monthPayrolls = payrolls.filter { it.month == month }
        val monthDailyEntries = dailyWorkerEntries.filter { it.date.startsWith(month) }

        // Total Income
        val totalIncome = monthIncomes.sumOf { it.amount }

        // Business vs Personal Expenses
        val personalExpenses = monthExpenses.filter {
            it.isPersonal || it.category.contains("ကိုယ်ရေးကိုယ်တာ")
        }.sumOf { it.amount }

        val generalExpenses = monthExpenses.filter {
            it.category.contains("အထွေထွေ") && !it.isPersonal
        }.sumOf { it.amount }

        val totalBusinessExpenses = monthExpenses.filter {
            !it.isPersonal && !it.category.contains("ကိုယ်ရေးကိုယ်တာ")
        }.sumOf { it.amount }

        // Total Salaries (sum of final pay from payrolls for this month)
        val totalSalaries = monthPayrolls.sumOf { it.finalPay }

        // Total Daily Worker (sum of total amounts)
        val totalDailyWorkerCost = monthDailyEntries.sumOf { it.totalAmount }

        // Business Profit
        val businessProfit = totalIncome - totalBusinessExpenses - totalSalaries - totalDailyWorkerCost

        // Final Remaining Amount after personal expenses
        val finalRemainingAmount = businessProfit - personalExpenses

        // Calculate Shop-by-Shop Summaries
        val allShopNames = (shops + monthIncomes.map { it.shop } + monthExpenses.map { it.shop } + monthPayrolls.map { it.shop })
            .filter { it.isNotBlank() && !it.contains("ကိုယ်ရေးကိုယ်တာ") }
            .distinct()

        val shopSummaries = allShopNames.map { shopName ->
            val shopIncome = monthIncomes.filter { it.shop.equals(shopName, ignoreCase = true) }.sumOf { it.amount }
            val shopExpense = monthExpenses.filter {
                !it.isPersonal && !it.category.contains("ကိုယ်ရေးကိုယ်တာ") &&
                        (it.shop.equals(shopName, ignoreCase = true) || it.category.contains(shopName))
            }.sumOf { it.amount }
            val shopSalaries = monthPayrolls.filter { it.shop.equals(shopName, ignoreCase = true) }.sumOf { it.finalPay }
            val shopDailyCost = 0.0 // daily workers generally belong to daily workers ledger or shop 1 if indicated

            val shopProfit = shopIncome - shopExpense - shopSalaries - shopDailyCost

            ShopFinancialSummary(
                shopName = shopName,
                totalIncome = shopIncome,
                totalExpenses = shopExpense,
                totalSalaries = shopSalaries,
                totalDailyWorkerCost = shopDailyCost,
                netProfit = shopProfit
            )
        }

        return OverallFinancialReport(
            month = month,
            totalIncome = totalIncome,
            totalBusinessExpenses = totalBusinessExpenses,
            totalSalaries = totalSalaries,
            totalDailyWorkerCost = totalDailyWorkerCost,
            businessProfit = businessProfit,
            personalExpenses = personalExpenses,
            generalExpenses = generalExpenses,
            finalRemainingAmount = finalRemainingAmount,
            shopSummaries = shopSummaries
        )
    }
}
