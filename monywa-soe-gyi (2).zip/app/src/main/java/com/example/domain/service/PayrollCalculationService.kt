package com.example.domain.service

import com.example.data.local.AdvanceEntity
import com.example.data.local.AttendanceEntity
import com.example.data.local.EmployeeEntity
import kotlin.math.max
import kotlin.math.roundToLong

data class PayrollCalculationResult(
    val employeeId: String,
    val employeeName: String,
    val shop: String,
    val month: String,
    val baseSalary: Double,
    val absentDays: Int,
    val dailySalary: Double,
    val absenceDeduction: Double,
    val attendanceBonus: Double,
    val attendancePenalty: Double,
    val effectiveAttendanceBonus: Double,
    val otherBonus: Double,
    val advanceDeduction: Double,
    val salaryBeforeAdvance: Double,
    val finalPay: Double
)

object PayrollCalculationService {

    fun calculateMonthlyPayroll(
        employee: EmployeeEntity,
        attendanceRecords: List<AttendanceEntity>,
        advances: List<AdvanceEntity>,
        yearMonth: String, // YYYY-MM
        penaltyRate: Double = 10000.0,
        otherBonus: Double = 0.0
    ): PayrollCalculationResult {
        val baseSalary = employee.salary
        val baseBonus = employee.bonus

        // Count absent days in the selected month
        // Note: Check joinDate and leaveDate if specified
        val absentDays = attendanceRecords.count { record ->
            record.status.equals("absent", ignoreCase = true)
        }

        // Daily salary rule: Monthly Salary / 30
        val dailySalary = if (baseSalary > 0) (baseSalary / 30.0).roundToLong().toDouble() else 0.0
        val absenceDeduction = absentDays * dailySalary

        // Attendance bonus logic:
        // 0 absent days -> Full bonus, 0 penalty
        // 1 absent day -> 10,000 MMK penalty deducted from bonus
        // 2 absent days -> 10,000 MMK penalty deducted from bonus
        // 3+ absent days -> Bonus becomes zero
        val attendancePenalty: Double
        val effectiveAttendanceBonus: Double

        when {
            baseBonus <= 0.0 -> {
                attendancePenalty = 0.0
                effectiveAttendanceBonus = 0.0
            }
            absentDays == 0 -> {
                attendancePenalty = 0.0
                effectiveAttendanceBonus = baseBonus
            }
            absentDays == 1 || absentDays == 2 -> {
                attendancePenalty = penaltyRate
                effectiveAttendanceBonus = max(0.0, baseBonus - penaltyRate)
            }
            else -> { // 3 or more absent days
                attendancePenalty = baseBonus
                effectiveAttendanceBonus = 0.0
            }
        }

        // Sum advances for the month
        val totalAdvance = advances.sumOf { it.amount }

        val salaryBeforeAdvance = baseSalary - absenceDeduction + effectiveAttendanceBonus + otherBonus
        val finalPay = max(0.0, salaryBeforeAdvance - totalAdvance)

        return PayrollCalculationResult(
            employeeId = employee.id,
            employeeName = employee.name,
            shop = employee.shop,
            month = yearMonth,
            baseSalary = baseSalary,
            absentDays = absentDays,
            dailySalary = dailySalary,
            absenceDeduction = absenceDeduction,
            attendanceBonus = baseBonus,
            attendancePenalty = attendancePenalty,
            effectiveAttendanceBonus = effectiveAttendanceBonus,
            otherBonus = otherBonus,
            advanceDeduction = totalAdvance,
            salaryBeforeAdvance = salaryBeforeAdvance,
            finalPay = finalPay
        )
    }
}
