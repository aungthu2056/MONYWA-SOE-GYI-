package com.example.domain.service

import com.example.data.local.*
import org.json.JSONArray
import org.json.JSONObject

data class BackupDataContainer(
    val exportDate: String,
    val appVersion: String,
    val businessName: String,
    val shops: List<ShopEntity>,
    val employees: List<EmployeeEntity>,
    val attendance: List<AttendanceEntity>,
    val advances: List<AdvanceEntity>,
    val payroll: List<PayrollEntity>,
    val dailyWorkers: List<DailyWorkerEntity>,
    val dailyWorkerTypes: List<DailyWorkerTypeEntity>,
    val dailyWorkerEntries: List<DailyWorkerEntryEntity>,
    val settlements: List<DailyWorkerSettlementEntity>,
    val income: List<IncomeEntity>,
    val expenses: List<ExpenseEntity>,
    val settings: List<AppSettingEntity>
)

object BackupRestoreService {

    fun createBackupJson(data: BackupDataContainer): String {
        val root = JSONObject()
        root.put("app", "MONYWA_SOE_GYI")
        root.put("exportDate", data.exportDate)
        root.put("appVersion", data.appVersion)
        root.put("businessName", data.businessName)

        // Shops
        val shopsArray = JSONArray()
        data.shops.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("name", it.name)
            obj.put("active", it.active)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            shopsArray.put(obj)
        }
        root.put("shops", shopsArray)

        // Employees
        val empArray = JSONArray()
        data.employees.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("business", it.business)
            obj.put("shop", it.shop)
            obj.put("name", it.name)
            obj.put("salary", it.salary)
            obj.put("bonus", it.bonus)
            obj.put("joinDate", it.joinDate ?: JSONObject.NULL)
            obj.put("leaveDate", it.leaveDate ?: JSONObject.NULL)
            obj.put("employeeType", it.employeeType)
            obj.put("dayWorkerType", it.dayWorkerType ?: JSONObject.NULL)
            obj.put("notes", it.notes)
            obj.put("active", it.active)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            empArray.put(obj)
        }
        root.put("employees", empArray)

        // Attendance
        val attArray = JSONArray()
        data.attendance.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("employeeId", it.employeeId)
            obj.put("date", it.date)
            obj.put("status", it.status)
            obj.put("reason", it.reason)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            attArray.put(obj)
        }
        root.put("attendance", attArray)

        // Advances
        val advArray = JSONArray()
        data.advances.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("employeeId", it.employeeId)
            obj.put("date", it.date)
            obj.put("amount", it.amount)
            obj.put("note", it.note)
            obj.put("payrollMonth", it.payrollMonth ?: JSONObject.NULL)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            advArray.put(obj)
        }
        root.put("advances", advArray)

        // Payroll
        val payArray = JSONArray()
        data.payroll.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("employeeId", it.employeeId)
            obj.put("employeeName", it.employeeName)
            obj.put("shop", it.shop)
            obj.put("month", it.month)
            obj.put("baseSalary", it.baseSalary)
            obj.put("absentDays", it.absentDays)
            obj.put("dailySalary", it.dailySalary)
            obj.put("absenceDeduction", it.absenceDeduction)
            obj.put("attendanceBonus", it.attendanceBonus)
            obj.put("attendancePenalty", it.attendancePenalty)
            obj.put("otherBonus", it.otherBonus)
            obj.put("advanceDeduction", it.advanceDeduction)
            obj.put("finalPay", it.finalPay)
            obj.put("status", it.status)
            obj.put("paidDate", it.paidDate ?: JSONObject.NULL)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            payArray.put(obj)
        }
        root.put("payroll", payArray)

        // Daily Workers
        val dwArray = JSONArray()
        data.dailyWorkers.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("name", it.name)
            obj.put("type", it.type)
            obj.put("active", it.active)
            obj.put("notes", it.notes)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            dwArray.put(obj)
        }
        root.put("dailyWorkers", dwArray)

        // Daily Worker Types
        val dwtArray = JSONArray()
        data.dailyWorkerTypes.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("name", it.name)
            obj.put("unit", it.unit)
            obj.put("defaultRate", it.defaultRate)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            dwtArray.put(obj)
        }
        root.put("dailyWorkerTypes", dwtArray)

        // Daily Worker Entries
        val dweArray = JSONArray()
        data.dailyWorkerEntries.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("workerId", it.workerId)
            obj.put("workerName", it.workerName)
            obj.put("date", it.date)
            obj.put("workerType", it.workerType)
            obj.put("quantity", it.quantity)
            obj.put("unit", it.unit)
            obj.put("pricePerUnit", it.pricePerUnit)
            obj.put("totalAmount", it.totalAmount)
            obj.put("advance", it.advance)
            obj.put("notes", it.notes)
            obj.put("settlementId", it.settlementId ?: JSONObject.NULL)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            dweArray.put(obj)
        }
        root.put("dailyWorkerEntries", dweArray)

        // Settlements
        val setArray = JSONArray()
        data.settlements.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("workerId", it.workerId)
            obj.put("workerName", it.workerName)
            obj.put("month", it.month)
            obj.put("totalQuantity", it.totalQuantity)
            obj.put("totalEarned", it.totalEarned)
            obj.put("totalAdvance", it.totalAdvance)
            obj.put("netPay", it.netPay)
            obj.put("settledDate", it.settledDate)
            obj.put("status", it.status)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            setArray.put(obj)
        }
        root.put("settlements", setArray)

        // Income
        val incArray = JSONArray()
        data.income.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("date", it.date)
            obj.put("shop", it.shop)
            obj.put("amount", it.amount)
            obj.put("description", it.description)
            obj.put("notes", it.notes)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            incArray.put(obj)
        }
        root.put("income", incArray)

        // Expenses
        val expArray = JSONArray()
        data.expenses.forEach {
            val obj = JSONObject()
            obj.put("id", it.id)
            obj.put("date", it.date)
            obj.put("category", it.category)
            obj.put("shop", it.shop)
            obj.put("amount", it.amount)
            obj.put("isPersonal", it.isPersonal)
            obj.put("description", it.description)
            obj.put("notes", it.notes)
            obj.put("createdAt", it.createdAt)
            obj.put("updatedAt", it.updatedAt)
            expArray.put(obj)
        }
        root.put("expenses", expArray)

        // Settings
        val settsArray = JSONArray()
        data.settings.forEach {
            val obj = JSONObject()
            obj.put("key", it.key)
            obj.put("value", it.value)
            obj.put("updatedAt", it.updatedAt)
            settsArray.put(obj)
        }
        root.put("settings", settsArray)

        return root.toString(2)
    }

    fun parseBackupJson(jsonString: String): BackupDataContainer {
        val root = JSONObject(jsonString)
        val exportDate = root.optString("exportDate", "")
        val appVersion = root.optString("appVersion", "1.0")
        val businessName = root.optString("businessName", "MONYWA SOE GYI")

        // Parse shops
        val shops = mutableListOf<ShopEntity>()
        root.optJSONArray("shops")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                shops.add(
                    ShopEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        active = obj.optBoolean("active", true),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse employees
        val employees = mutableListOf<EmployeeEntity>()
        root.optJSONArray("employees")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                employees.add(
                    EmployeeEntity(
                        id = obj.getString("id"),
                        business = obj.optString("business", "Monywa Soe Gyi"),
                        shop = obj.getString("shop"),
                        name = obj.getString("name"),
                        salary = obj.optDouble("salary", 0.0),
                        bonus = obj.optDouble("bonus", 0.0),
                        joinDate = if (obj.isNull("joinDate")) null else obj.optString("joinDate"),
                        leaveDate = if (obj.isNull("leaveDate")) null else obj.optString("leaveDate"),
                        employeeType = obj.optString("employeeType", "monthly"),
                        dayWorkerType = if (obj.isNull("dayWorkerType")) null else obj.optString("dayWorkerType"),
                        notes = obj.optString("notes", ""),
                        active = obj.optBoolean("active", true),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse attendance
        val attendance = mutableListOf<AttendanceEntity>()
        root.optJSONArray("attendance")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                attendance.add(
                    AttendanceEntity(
                        id = obj.getString("id"),
                        employeeId = obj.getString("employeeId"),
                        date = obj.getString("date"),
                        status = obj.optString("status", "present"),
                        reason = obj.optString("reason", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse advances
        val advances = mutableListOf<AdvanceEntity>()
        root.optJSONArray("advances")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                advances.add(
                    AdvanceEntity(
                        id = obj.getString("id"),
                        employeeId = obj.getString("employeeId"),
                        date = obj.getString("date"),
                        amount = obj.optDouble("amount", 0.0),
                        note = obj.optString("note", ""),
                        payrollMonth = if (obj.isNull("payrollMonth")) null else obj.optString("payrollMonth"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse payroll
        val payroll = mutableListOf<PayrollEntity>()
        root.optJSONArray("payroll")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                payroll.add(
                    PayrollEntity(
                        id = obj.getString("id"),
                        employeeId = obj.getString("employeeId"),
                        employeeName = obj.optString("employeeName", ""),
                        shop = obj.optString("shop", ""),
                        month = obj.getString("month"),
                        baseSalary = obj.optDouble("baseSalary", 0.0),
                        absentDays = obj.optInt("absentDays", 0),
                        dailySalary = obj.optDouble("dailySalary", 0.0),
                        absenceDeduction = obj.optDouble("absenceDeduction", 0.0),
                        attendanceBonus = obj.optDouble("attendanceBonus", 0.0),
                        attendancePenalty = obj.optDouble("attendancePenalty", 0.0),
                        otherBonus = obj.optDouble("otherBonus", 0.0),
                        advanceDeduction = obj.optDouble("advanceDeduction", 0.0),
                        finalPay = obj.optDouble("finalPay", 0.0),
                        status = obj.optString("status", "draft"),
                        paidDate = if (obj.isNull("paidDate")) null else obj.optString("paidDate"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse daily workers
        val dailyWorkers = mutableListOf<DailyWorkerEntity>()
        root.optJSONArray("dailyWorkers")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                dailyWorkers.add(
                    DailyWorkerEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        type = obj.optString("type", "ကွမ်းသီးစိတ်"),
                        active = obj.optBoolean("active", true),
                        notes = obj.optString("notes", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse worker types
        val dailyWorkerTypes = mutableListOf<DailyWorkerTypeEntity>()
        root.optJSONArray("dailyWorkerTypes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                dailyWorkerTypes.add(
                    DailyWorkerTypeEntity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        unit = obj.optString("unit", "ပိသာ"),
                        defaultRate = obj.optDouble("defaultRate", 10000.0),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse daily worker entries
        val dailyWorkerEntries = mutableListOf<DailyWorkerEntryEntity>()
        root.optJSONArray("dailyWorkerEntries")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                dailyWorkerEntries.add(
                    DailyWorkerEntryEntity(
                        id = obj.getString("id"),
                        workerId = obj.getString("workerId"),
                        workerName = obj.optString("workerName", ""),
                        date = obj.getString("date"),
                        workerType = obj.optString("workerType", "ကွမ်းသီးစိတ်"),
                        quantity = obj.optDouble("quantity", 0.0),
                        unit = obj.optString("unit", "ပိသာ"),
                        pricePerUnit = obj.optDouble("pricePerUnit", 0.0),
                        totalAmount = obj.optDouble("totalAmount", 0.0),
                        advance = obj.optDouble("advance", 0.0),
                        notes = obj.optString("notes", ""),
                        settlementId = if (obj.isNull("settlementId")) null else obj.optString("settlementId"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse settlements
        val settlements = mutableListOf<DailyWorkerSettlementEntity>()
        root.optJSONArray("settlements")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                settlements.add(
                    DailyWorkerSettlementEntity(
                        id = obj.getString("id"),
                        workerId = obj.getString("workerId"),
                        workerName = obj.optString("workerName", ""),
                        month = obj.getString("month"),
                        totalQuantity = obj.optDouble("totalQuantity", 0.0),
                        totalEarned = obj.optDouble("totalEarned", 0.0),
                        totalAdvance = obj.optDouble("totalAdvance", 0.0),
                        netPay = obj.optDouble("netPay", 0.0),
                        settledDate = obj.optString("settledDate", ""),
                        status = obj.optString("status", "paid"),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse income
        val income = mutableListOf<IncomeEntity>()
        root.optJSONArray("income")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                income.add(
                    IncomeEntity(
                        id = obj.getString("id"),
                        date = obj.getString("date"),
                        shop = obj.getString("shop"),
                        amount = obj.optDouble("amount", 0.0),
                        description = obj.optString("description", ""),
                        notes = obj.optString("notes", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse expenses
        val expenses = mutableListOf<ExpenseEntity>()
        root.optJSONArray("expenses")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                expenses.add(
                    ExpenseEntity(
                        id = obj.getString("id"),
                        date = obj.getString("date"),
                        category = obj.getString("category"),
                        shop = obj.optString("shop", ""),
                        amount = obj.optDouble("amount", 0.0),
                        isPersonal = obj.optBoolean("isPersonal", false),
                        description = obj.optString("description", ""),
                        notes = obj.optString("notes", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        // Parse settings
        val settings = mutableListOf<AppSettingEntity>()
        root.optJSONArray("settings")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                settings.add(
                    AppSettingEntity(
                        key = obj.getString("key"),
                        value = obj.getString("value"),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
        }

        return BackupDataContainer(
            exportDate = exportDate,
            appVersion = appVersion,
            businessName = businessName,
            shops = shops,
            employees = employees,
            attendance = attendance,
            advances = advances,
            payroll = payroll,
            dailyWorkers = dailyWorkers,
            dailyWorkerTypes = dailyWorkerTypes,
            dailyWorkerEntries = dailyWorkerEntries,
            settlements = settlements,
            income = income,
            expenses = expenses,
            settings = settings
        )
    }
}
